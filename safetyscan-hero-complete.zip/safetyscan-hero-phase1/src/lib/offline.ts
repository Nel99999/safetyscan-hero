'use client';

import { useEffect } from 'react';

// Register service worker
export function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('/service-worker.js')
        .then(registration => {
          console.log('Service Worker registered with scope:', registration.scope);
        })
        .catch(error => {
          console.error('Service Worker registration failed:', error);
        });
    });
  }
}

// Local storage service for offline data
export const localStorageService = {
  // Templates
  saveTemplates: (templates: any[]) => {
    localStorage.setItem('safetyscan_templates', JSON.stringify(templates));
  },
  
  getTemplates: (): any[] => {
    const templates = localStorage.getItem('safetyscan_templates');
    return templates ? JSON.parse(templates) : [];
  },
  
  // Inspections
  saveInspections: (inspections: any[]) => {
    localStorage.setItem('safetyscan_inspections', JSON.stringify(inspections));
  },
  
  getInspections: (): any[] => {
    const inspections = localStorage.getItem('safetyscan_inspections');
    return inspections ? JSON.parse(inspections) : [];
  },
  
  // Single inspection
  saveInspection: (inspection: any) => {
    const inspections = localStorageService.getInspections();
    const index = inspections.findIndex(i => i.id === inspection.id);
    
    if (index !== -1) {
      inspections[index] = inspection;
    } else {
      inspections.push(inspection);
    }
    
    localStorageService.saveInspections(inspections);
  },
  
  getInspection: (id: number): any | null => {
    const inspections = localStorageService.getInspections();
    return inspections.find(i => i.id === id) || null;
  },
  
  // Pending changes for sync
  savePendingChanges: (changes: any[]) => {
    localStorage.setItem('safetyscan_pending_changes', JSON.stringify(changes));
  },
  
  getPendingChanges: (): any[] => {
    const changes = localStorage.getItem('safetyscan_pending_changes');
    return changes ? JSON.parse(changes) : [];
  },
  
  addPendingChange: (change: any) => {
    const changes = localStorageService.getPendingChanges();
    changes.push({
      ...change,
      timestamp: new Date().toISOString()
    });
    localStorageService.savePendingChanges(changes);
  },
  
  removePendingChange: (index: number) => {
    const changes = localStorageService.getPendingChanges();
    changes.splice(index, 1);
    localStorageService.savePendingChanges(changes);
  },
  
  // User data
  saveUserData: (userData: any) => {
    localStorage.setItem('safetyscan_user_data', JSON.stringify(userData));
  },
  
  getUserData: (): any | null => {
    const userData = localStorage.getItem('safetyscan_user_data');
    return userData ? JSON.parse(userData) : null;
  },
  
  // Connection status
  isOnline: (): boolean => {
    return navigator.onLine;
  }
};

// Network status hook
export function useNetworkStatus() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  
  return isOnline;
}

// Sync service
export const syncService = {
  syncPendingChanges: async (supabase: any) => {
    if (!localStorageService.isOnline()) {
      return { success: false, message: 'No internet connection' };
    }
    
    const pendingChanges = localStorageService.getPendingChanges();
    if (pendingChanges.length === 0) {
      return { success: true, message: 'No pending changes to sync' };
    }
    
    const results = [];
    
    for (let i = 0; i < pendingChanges.length; i++) {
      const change = pendingChanges[i];
      
      try {
        let result;
        
        switch (change.type) {
          case 'create_inspection':
            result = await supabase
              .from('inspections')
              .insert(change.data)
              .select();
            break;
            
          case 'update_inspection':
            result = await supabase
              .from('inspections')
              .update(change.data)
              .eq('id', change.id)
              .select();
            break;
            
          case 'create_template':
            result = await supabase
              .from('templates')
              .insert(change.data)
              .select();
            break;
            
          case 'update_template':
            result = await supabase
              .from('templates')
              .update(change.data)
              .eq('id', change.id)
              .select();
            break;
            
          default:
            throw new Error(`Unknown change type: ${change.type}`);
        }
        
        if (result.error) {
          throw result.error;
        }
        
        // Remove the successfully synced change
        localStorageService.removePendingChange(i);
        i--; // Adjust index since we removed an item
        
        results.push({
          success: true,
          change,
          data: result.data
        });
      } catch (error) {
        console.error('Error syncing change:', error);
        results.push({
          success: false,
          change,
          error
        });
      }
    }
    
    return {
      success: results.every(r => r.success),
      results
    };
  }
};

// Offline data hook
export function useOfflineData() {
  const isOnline = useNetworkStatus();
  
  return {
    isOnline,
    localStorageService,
    syncService
  };
}
