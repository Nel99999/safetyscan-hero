'use client';

import { useEffect } from 'react';
import { registerServiceWorker, localStorageService, useNetworkStatus, syncService } from '@/lib/offline';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/app/auth/context/AuthContext';

export default function OfflineProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const isOnline = useNetworkStatus();

  // Register service worker on mount
  useEffect(() => {
    registerServiceWorker();
  }, []);

  // Sync data when coming back online
  useEffect(() => {
    if (isOnline) {
      syncPendingChanges();
    }
  }, [isOnline]);

  // Cache user data when it changes
  useEffect(() => {
    if (user) {
      localStorageService.saveUserData(user);
    }
  }, [user]);

  // Cache templates and inspections periodically
  useEffect(() => {
    if (isOnline && user) {
      fetchAndCacheData();
      
      // Set up periodic sync
      const syncInterval = setInterval(fetchAndCacheData, 5 * 60 * 1000); // Every 5 minutes
      
      return () => clearInterval(syncInterval);
    }
  }, [isOnline, user]);

  async function fetchAndCacheData() {
    try {
      // Fetch and cache templates
      const { data: templates, error: templatesError } = await supabase
        .from('templates')
        .select('*');
        
      if (templatesError) {
        throw templatesError;
      }
      
      if (templates) {
        localStorageService.saveTemplates(templates);
      }
      
      // Fetch and cache inspections
      const { data: inspections, error: inspectionsError } = await supabase
        .from('inspections')
        .select('*, template:template_id (title, description, sections)');
        
      if (inspectionsError) {
        throw inspectionsError;
      }
      
      if (inspections) {
        localStorageService.saveInspections(inspections);
      }
    } catch (error) {
      console.error('Error caching data:', error);
    }
  }

  async function syncPendingChanges() {
    try {
      const result = await syncService.syncPendingChanges(supabase);
      console.log('Sync result:', result);
      
      // Refresh cached data after sync
      if (result.success) {
        fetchAndCacheData();
      }
    } catch (error) {
      console.error('Error syncing pending changes:', error);
    }
  }

  return (
    <>
      {!isOnline && (
        <div className="bg-yellow-100 border-b border-yellow-500 text-yellow-700 px-4 py-2 text-center">
          You are currently offline. Your changes will be saved and synchronized when you're back online.
        </div>
      )}
      {children}
    </>
  );
}
