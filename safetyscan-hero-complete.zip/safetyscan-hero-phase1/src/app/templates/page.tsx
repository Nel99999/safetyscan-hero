'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { useAuth } from '../auth/context/AuthContext';
import ProtectedRoute from '../auth/components/ProtectedRoute';

interface Template {
  id: number;
  created_at: string;
  title: string;
  description: string;
  version: number;
  category: string | null;
  tags: string[] | null;
  user_id: string | null;
}

export default function TemplatesPage() {
  const { user } = useAuth();
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [newTemplate, setNewTemplate] = useState({ 
    title: '', 
    description: '', 
    category: '',
    tags: ''
  });
  const [showForm, setShowForm] = useState(false);
  const [categories, setCategories] = useState<string[]>([
    'Fire Safety', 'Electrical', 'PPE', 'Machinery', 'Chemical', 'Environmental', 'General'
  ]);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  useEffect(() => {
    fetchTemplates();
  }, [selectedCategory]);

  async function fetchTemplates() {
    try {
      setLoading(true);
      let query = supabase
        .from('templates')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (selectedCategory) {
        query = query.eq('category', selectedCategory);
      }

      const { data, error } = await query;

      if (error) {
        throw error;
      }

      if (data) {
        setTemplates(data);
      }
    } catch (error) {
      console.error('Error fetching templates:', error);
    } finally {
      setLoading(false);
    }
  }

  async function createTemplate() {
    try {
      if (!newTemplate.title) return;
      
      // Parse tags from comma-separated string to array
      const tagsArray = newTemplate.tags
        ? newTemplate.tags.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0)
        : null;

      const { data, error } = await supabase
        .from('templates')
        .insert([
          {
            title: newTemplate.title,
            description: newTemplate.description,
            category: newTemplate.category || null,
            tags: tagsArray,
            version: 1, // Initial version
            user_id: user?.id || null
          },
        ])
        .select();

      if (error) {
        throw error;
      }

      if (data) {
        setTemplates([...data, ...templates]);
        setNewTemplate({ title: '', description: '', category: '', tags: '' });
        setShowForm(false);
      }
    } catch (error) {
      console.error('Error creating template:', error);
    }
  }

  function getCategoryBadgeColor(category: string | null) {
    if (!category) return 'bg-gray-100 text-gray-800';
    
    switch(category.toLowerCase()) {
      case 'fire safety':
        return 'bg-red-100 text-red-800';
      case 'electrical':
        return 'bg-yellow-100 text-yellow-800';
      case 'ppe':
        return 'bg-blue-100 text-blue-800';
      case 'machinery':
        return 'bg-purple-100 text-purple-800';
      case 'chemical':
        return 'bg-green-100 text-green-800';
      case 'environmental':
        return 'bg-teal-100 text-teal-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Safety Templates</h1>
          <button
            onClick={() => setShowForm(!showForm)}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          >
            {showForm ? 'Cancel' : 'Create New Template'}
          </button>
        </div>

        {/* Category Filter */}
        <div className="mb-6">
          <h2 className="text-lg font-semibold mb-2">Filter by Category</h2>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-3 py-1 rounded-full text-sm font-medium ${
                selectedCategory === null ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
              }`}
            >
              All
            </button>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  selectedCategory === category 
                    ? 'bg-blue-500 text-white' 
                    : `${getCategoryBadgeColor(category)}`
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {showForm && (
          <div className="bg-gray-100 p-6 rounded-lg mb-6">
            <h2 className="text-xl font-semibold mb-4">Create New Template</h2>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Title
              </label>
              <input
                type="text"
                value={newTemplate.title}
                onChange={(e) => setNewTemplate({ ...newTemplate, title: e.target.value })}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                placeholder="Enter template title"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Description
              </label>
              <textarea
                value={newTemplate.description}
                onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                placeholder="Enter template description"
                rows={3}
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Category
              </label>
              <select
                value={newTemplate.category}
                onChange={(e) => setNewTemplate({ ...newTemplate, category: e.target.value })}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              >
                <option value="">Select a category</option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">
                Tags (comma-separated)
              </label>
              <input
                type="text"
                value={newTemplate.tags}
                onChange={(e) => setNewTemplate({ ...newTemplate, tags: e.target.value })}
                className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                placeholder="e.g., construction, warehouse, monthly"
              />
            </div>
            <button
              onClick={createTemplate}
              className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
            >
              Save Template
            </button>
          </div>
        )}

        {loading ? (
          <p>Loading templates...</p>
        ) : templates.length === 0 ? (
          <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6">
            <p>No templates found. Create your first safety template!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {templates.map((template) => (
              <div key={template.id} className="border rounded-lg overflow-hidden shadow-lg">
                <div className="p-6">
                  <div className="flex justify-between items-start mb-2">
                    <h2 className="text-xl font-semibold">{template.title}</h2>
                    <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full">
                      v{template.version || 1}
                    </span>
                  </div>
                  <p className="text-gray-600 mb-4">{template.description}</p>
                  
                  {/* Category and Tags */}
                  <div className="mb-4">
                    {template.category && (
                      <span className={`inline-block ${getCategoryBadgeColor(template.category)} px-2 py-1 rounded-full text-xs font-medium mr-2`}>
                        {template.category}
                      </span>
                    )}
                    {template.tags && template.tags.map((tag, index) => (
                      <span key={index} className="inline-block bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs font-medium mr-1 mb-1">
                        {tag}
                      </span>
                    ))}
                  </div>
                  
                  <div className="flex justify-between">
                    <Link
                      href={`/templates/${template.id}`}
                      className="text-blue-500 hover:text-blue-700"
                    >
                      View Details
                    </Link>
                    <Link
                      href={`/inspections/new?templateId=${template.id}`}
                      className="bg-green-500 hover:bg-green-700 text-white font-bold py-1 px-3 rounded text-sm"
                    >
                      Start Inspection
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-8">
          <Link href="/" className="text-blue-500 hover:text-blue-700">
            ← Back to Home
          </Link>
        </div>
      </div>
    </ProtectedRoute>
  );
}
