'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { useAuth } from '../../auth/context/AuthContext';
import ProtectedRoute from '../../auth/components/ProtectedRoute';

interface Template {
  id: number;
  created_at: string;
  title: string;
  description: string;
  version: number;
  category: string | null;
  tags: string[] | null;
  user_id: string | null;
  sections?: TemplateSection[];
}

interface TemplateSection {
  id: string;
  title: string;
  description?: string;
  questions: TemplateQuestion[];
}

interface TemplateQuestion {
  id: string;
  text: string;
  type: 'text' | 'yesno' | 'multiple' | 'checkbox';
  options?: string[];
  required: boolean;
}

export default function TemplateDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const [template, setTemplate] = useState<Template | null>(null);
  const [loading, setLoading] = useState(true);
  const [versions, setVersions] = useState<Template[]>([]);
  const [showVersionHistory, setShowVersionHistory] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editedTemplate, setEditedTemplate] = useState<Template | null>(null);
  const [sections, setSections] = useState<TemplateSection[]>([]);
  const [newSection, setNewSection] = useState({ title: '', description: '' });
  const [showSectionForm, setShowSectionForm] = useState(false);

  useEffect(() => {
    if (params.id) {
      fetchTemplate(parseInt(params.id as string));
      fetchVersionHistory(parseInt(params.id as string));
    }
  }, [params.id]);

  async function fetchTemplate(templateId: number) {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('templates')
        .select('*')
        .eq('id', templateId)
        .single();

      if (error) {
        throw error;
      }

      if (data) {
        setTemplate(data);
        setEditedTemplate(data);
        
        // Initialize sections if they exist in the template
        if (data.sections) {
          setSections(data.sections);
        } else {
          setSections([]);
        }
      }
    } catch (error) {
      console.error('Error fetching template:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchVersionHistory(templateId: number) {
    try {
      // In a real implementation, this would query a template_versions table
      // For now, we'll simulate with the current template
      const { data, error } = await supabase
        .from('templates')
        .select('*')
        .eq('id', templateId);

      if (error) {
        throw error;
      }

      if (data && data.length > 0) {
        // In a real implementation, this would show actual versions
        // For now, we'll simulate with the current version
        setVersions([data[0]]);
      }
    } catch (error) {
      console.error('Error fetching version history:', error);
    }
  }

  async function updateTemplate() {
    if (!editedTemplate || !template) return;
    
    try {
      setLoading(true);
      
      // Parse tags if it's a string (from form input)
      let tagsArray = editedTemplate.tags;
      if (typeof editedTemplate.tags === 'string') {
        tagsArray = (editedTemplate.tags as unknown as string)
          .split(',')
          .map(tag => tag.trim())
          .filter(tag => tag.length > 0);
      }
      
      // Create a new version
      const newVersion = template.version + 1;
      
      const { data, error } = await supabase
        .from('templates')
        .update({
          title: editedTemplate.title,
          description: editedTemplate.description,
          category: editedTemplate.category,
          tags: tagsArray,
          version: newVersion,
          sections: sections,
        })
        .eq('id', template.id)
        .select();

      if (error) {
        throw error;
      }

      if (data && data[0]) {
        setTemplate(data[0]);
        setEditMode(false);
        // Refresh version history
        fetchVersionHistory(template.id);
      }
    } catch (error) {
      console.error('Error updating template:', error);
    } finally {
      setLoading(false);
    }
  }

  function addSection() {
    if (!newSection.title) return;
    
    const newSectionObj: TemplateSection = {
      id: Date.now().toString(),
      title: newSection.title,
      description: newSection.description,
      questions: []
    };
    
    setSections([...sections, newSectionObj]);
    setNewSection({ title: '', description: '' });
    setShowSectionForm(false);
  }

  function removeSection(sectionId: string) {
    setSections(sections.filter(section => section.id !== sectionId));
  }

  function addQuestion(sectionId: string) {
    const updatedSections = sections.map(section => {
      if (section.id === sectionId) {
        return {
          ...section,
          questions: [
            ...section.questions,
            {
              id: Date.now().toString(),
              text: 'New question',
              type: 'text',
              required: false
            }
          ]
        };
      }
      return section;
    });
    
    setSections(updatedSections);
  }

  function updateQuestion(sectionId: string, questionId: string, updates: Partial<TemplateQuestion>) {
    const updatedSections = sections.map(section => {
      if (section.id === sectionId) {
        return {
          ...section,
          questions: section.questions.map(question => {
            if (question.id === questionId) {
              return { ...question, ...updates };
            }
            return question;
          })
        };
      }
      return section;
    });
    
    setSections(updatedSections);
  }

  function removeQuestion(sectionId: string, questionId: string) {
    const updatedSections = sections.map(section => {
      if (section.id === sectionId) {
        return {
          ...section,
          questions: section.questions.filter(question => question.id !== questionId)
        };
      }
      return section;
    });
    
    setSections(updatedSections);
  }

  function getCategoryBadgeColor(category: string | null) {
    if (!category) return 'bg-gray-100 text-gray-800';
    
    switch(category.toLowerCase()) {
      case 'fire safety':
        return 'bg-red-100 text-red-800';
      case 'electrical':
        return 'bg-yellow-100 text-yellow-800';
      case 'ppe':
        return 'bg-blue-100 text-blue-800';
      case 'machinery':
        return 'bg-purple-100 text-purple-800';
      case 'chemical':
        return 'bg-green-100 text-green-800';
      case 'environmental':
        return 'bg-teal-100 text-teal-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  if (loading && !template) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>;
  }

  if (!template) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
          <p>Template not found.</p>
        </div>
        <Link href="/templates" className="text-blue-500 hover:text-blue-700">
          ← Back to Templates
        </Link>
      </div>
    );
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        {editMode ? (
          <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <div className="flex justify-between items-center mb-6">
              <h1 className="text-3xl font-bold">Edit Template</h1>
              <div className="flex space-x-2">
                <button
                  onClick={() => setEditMode(false)}
                  className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={updateTemplate}
                  className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
                >
                  Save Changes
                </button>
              </div>
            </div>
            
            <div className="mb-6">
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  Title
                </label>
                <input
                  type="text"
                  value={editedTemplate.title}
                  onChange={(e) => setEditedTemplate({ ...editedTemplate, title: e.target.value })}
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  Description
                </label>
                <textarea
                  value={editedTemplate.description}
                  onChange={(e) => setEditedTemplate({ ...editedTemplate, description: e.target.value })}
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  rows={3}
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  Category
                </label>
                <select
                  value={editedTemplate.category || ''}
                  onChange={(e) => setEditedTemplate({ ...editedTemplate, category: e.target.value })}
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                >
                  <option value="">Select a category</option>
                  <option value="Fire Safety">Fire Safety</option>
                  <option value="Electrical">Electrical</option>
                  <option value="PPE">PPE</option>
                  <option value="Machinery">Machinery</option>
                  <option value="Chemical">Chemical</option>
                  <option value="Environmental">Environmental</option>
                  <option value="General">General</option>
                </select>
              </div>
              
              <div className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                  Tags (comma-separated)
                </label>
                <input
                  type="text"
                  value={Array.isArray(editedTemplate.tags) ? editedTemplate.tags.join(', ') : ''}
                  onChange={(e) => setEditedTemplate({ ...editedTemplate, tags: e.target.value })}
                  className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                />
              </div>
            </div>
            
            <div className="mb-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold">Template Sections</h2>
                <button
                  onClick={() => setShowSectionForm(!showSectionForm)}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-3 rounded text-sm"
                >
                  {showSectionForm ? 'Cancel' : 'Add Section'}
                </button>
              </div>
              
              {showSectionForm && (
                <div className="bg-gray-100 p-4 rounded mb-4">
                  <div className="mb-3">
                    <label className="block text-gray-700 text-sm font-bold mb-2">
                      Section Title
                    </label>
                    <input
                      type="text"
                      value={newSection.title}
                      onChange={(e) => setNewSection({ ...newSection, title: e.target.value })}
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    />
                  </div>
                  <div className="mb-3">
                    <label className="block text-gray-700 text-sm font-bold mb-2">
                      Section Description
                    </label>
                    <textarea
                      value={newSection.description}
                      onChange={(e) => setNewSection({ ...newSection, description: e.target.value })}
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      rows={2}
                    />
                  </div>
                  <button
                    onClick={addSection}
                    className="bg-green-500 hover:bg-green-700 text-white font-bold py-1 px-3 rounded text-sm"
                  >
                    Add Section
                  </button>
                </div>
              )}
              
              {sections.length === 0 ? (
                <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4">
                  <p>No sections added yet. Add sections to organize your template.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {sections.map((section, index) => (
                    <div key={section.id} className="border rounded p-4">
                      <div className="flex justify-between items-center mb-2">
                        <h3 className="font-semibold">
                          Section {index + 1}: {section.title}
                        </h3>
                        <button
                          onClick={() => removeSection(section.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          Remove
                        </button>
                      </div>
                      
                      {section.description && (
                        <p className="text-gray-600 mb-3">{section.description}</p>
                      )}
                      
                      <div className="mt-3">
                        <div className="flex justify-between items-center mb-2">
                          <h4 className="font-medium">Questions</h4>
                          <button
                            onClick={() => addQuestion(section.id)}
                            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded text-xs"
                          >
                            Add Question
                          </button>
                        </div>
                        
                        {section.questions && section.questions.length > 0 ? (
                          <div className="space-y-3">
                            {section.questions.map((question, qIndex) => (
                              <div key={question.id} className="bg-gray-50 p-3 rounded">
                                <div className="flex justify-between items-start">
                                  <div className="flex-1">
                                    <input
                                      type="text"
                                      value={question.text}
                                      onChange={(e) => updateQuestion(section.id, question.id, { text: e.target.value })}
                                      className="w-full p-1 border rounded mb-2"
                                      placeholder="Question text"
                                    />
                                    
                                    <div className="flex space-x-4 mb-2">
                                      <select
                                        value={question.type}
                                        onChange={(e) => updateQuestion(section.id, question.id, { type: e.target.value as any })}
                                        className="p-1 border rounded"
                                      >
                                        <option value="text">Text</option>
                                        <option value="yesno">Yes/No</option>
                                        <option value="multiple">Multiple Choice</option>
                                        <option value="checkbox">Checkbox</option>
                                      </select>
                                      
                                      <label className="flex items-center">
                                        <input
                                          type="checkbox"
                                          checked={question.required}
                                          onChange={(e) => updateQuestion(section.id, question.id, { required: e.target.checked })}
                                          className="mr-1"
                                        />
                                        Required
                                      </label>
                                    </div>
                                    
                                    {(question.type === 'multiple' || question.type === 'checkbox') && (
                                      <div className="mt-2">
                                        <label className="block text-sm mb-1">Options (comma-separated)</label>
                                        <input
                                          type="text"
                                          value={question.options?.join(', ') || ''}
                                          onChange={(e) => {
                                            const options = e.target.value
                                              .split(',')
                                              .map(opt => opt.trim())
                                              .filter(opt => opt.length > 0);
                                            updateQuestion(section.id, question.id, { options });
                                          }}
                                          className="w-full p-1 border rounded"
                                          placeholder="Option 1, Option 2, Option 3"
                                        />
                                      </div>
                                    )}
                                  </div>
                                  
                                  <button
                                    onClick={() => removeQuestion(section.id, question.id)}
                                    className="text-red-500 hover:text-red-700 ml-2"
                                  >
                                    Remove
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <p className="text-gray-500 text-sm italic">No questions added yet.</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <div className="flex justify-between items-center mb-6">
              <div>
                <h1 className="text-3xl font-bold">{template.title}</h1>
                <div className="flex items-center mt-2">
                  <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded-full mr-2">
                    v{template.version || 1}
                  </span>
                  <button
                    onClick={() => setShowVersionHistory(!showVersionHistory)}
                    className="text-blue-500 hover:text-blue-700 text-sm"
                  >
                    {showVersionHistory ? 'Hide Version History' : 'Show Version History'}
                  </button>
                </div>
              </div>
              
              {user && (
                <button
                  onClick={() => setEditMode(true)}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                >
                  Edit Template
                </button>
              )}
            </div>
            
            {showVersionHistory && (
              <div className="mb-6">
                <h2 className="text-xl font-semibold mb-2">Version History</h2>
                {versions.length > 0 ? (
                  <div className="bg-gray-50 p-4 rounded">
                    <ul className="divide-y divide-gray-200">
                      {versions.map((version, index) => (
                        <li key={index} className="py-2">
                          <div className="flex justify-between">
                            <div>
                              <span className="font-medium">Version {version.version || 1}</span>
                              <span className="text-gray-500 ml-2">
                                {new Date(version.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            {index === 0 && (
                              <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">
                                Current
                              </span>
                            )}
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                ) : (
                  <p className="text-gray-500">No version history available.</p>
                )}
              </div>
            )}
            
            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-2">Description</h2>
              <p className="text-gray-600">{template.description}</p>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-2">Details</h2>
              <div className="bg-gray-50 p-4 rounded">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-500 text-sm">Category</p>
                    {template.category ? (
                      <span className={`inline-block ${getCategoryBadgeColor(template.category)} px-2 py-1 rounded-full text-xs font-medium`}>
                        {template.category}
                      </span>
                    ) : (
                      <span className="text-gray-500">None</span>
                    )}
                  </div>
                  <div>
                    <p className="text-gray-500 text-sm">Tags</p>
                    <div>
                      {template.tags && template.tags.length > 0 ? (
                        template.tags.map((tag, index) => (
                          <span key={index} className="inline-block bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs font-medium mr-1 mb-1">
                            {tag}
                          </span>
                        ))
                      ) : (
                        <span className="text-gray-500">None</span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-2">Template Structure</h2>
              {sections && sections.length > 0 ? (
                <div className="space-y-4">
                  {sections.map((section, index) => (
                    <div key={section.id} className="border rounded p-4">
                      <h3 className="font-semibold mb-2">
                        Section {index + 1}: {section.title}
                      </h3>
                      
                      {section.description && (
                        <p className="text-gray-600 mb-3">{section.description}</p>
                      )}
                      
                      {section.questions && section.questions.length > 0 ? (
                        <div className="mt-3 space-y-3">
                          <h4 className="font-medium">Questions</h4>
                          {section.questions.map((question, qIndex) => (
                            <div key={question.id} className="bg-gray-50 p-3 rounded">
                              <div className="flex justify-between">
                                <div>
                                  <p className="font-medium">{qIndex + 1}. {question.text}</p>
                                  <p className="text-sm text-gray-500 mt-1">
                                    Type: {question.type.charAt(0).toUpperCase() + question.type.slice(1)}
                                    {question.required && ' (Required)'}
                                  </p>
                                  
                                  {(question.type === 'multiple' || question.type === 'checkbox') && question.options && (
                                    <div className="mt-2">
                                      <p className="text-sm text-gray-500">Options:</p>
                                      <ul className="list-disc list-inside text-sm pl-2">
                                        {question.options.map((option, oIndex) => (
                                          <li key={oIndex}>{option}</li>
                                        ))}
                                      </ul>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-gray-500 text-sm italic">No questions in this section.</p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4">
                  <p>This template doesn't have any sections defined yet.</p>
                </div>
              )}
            </div>
            
            <div className="flex justify-between mt-8">
              <Link href="/templates" className="text-blue-500 hover:text-blue-700">
                ← Back to Templates
              </Link>
              <Link
                href={`/inspections/new?templateId=${template.id}`}
                className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
              >
                Start Inspection
              </Link>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}
