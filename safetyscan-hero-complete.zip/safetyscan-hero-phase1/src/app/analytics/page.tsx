import React, { useState, useEffect } from 'react';
import { Bar, Line, Pie } from 'react-chartjs-2';
import { Chart, registerables } from 'chart.js';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/app/auth/context/AuthContext';
import ProtectedRoute from '@/app/auth/components/ProtectedRoute';

// Register Chart.js components
Chart.register(...registerables);

export default function AnalyticsDashboard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [inspectionData, setInspectionData] = useState({
    total: 0,
    completed: 0,
    inProgress: 0
  });
  const [findingsBySeverity, setFindingsBySeverity] = useState({
    low: 0,
    medium: 0,
    high: 0,
    critical: 0
  });
  const [inspectionsByMonth, setInspectionsByMonth] = useState([]);
  const [templateUsage, setTemplateUsage] = useState([]);
  const [timeframeFilter, setTimeframeFilter] = useState('all');

  useEffect(() => {
    fetchAnalyticsData();
  }, [timeframeFilter]);

  async function fetchAnalyticsData() {
    try {
      setLoading(true);
      
      // Get date range based on timeframe filter
      const dateFilter = getDateFilter(timeframeFilter);
      
      // Fetch inspections
      let query = supabase
        .from('inspections')
        .select('*');
        
      if (dateFilter) {
        query = query.gte('created_at', dateFilter);
      }
      
      const { data: inspections, error: inspectionsError } = await query;
      
      if (inspectionsError) {
        throw inspectionsError;
      }
      
      // Process inspection status data
      const completed = inspections.filter(i => i.status.toLowerCase() === 'completed').length;
      const inProgress = inspections.filter(i => i.status.toLowerCase() === 'in progress').length;
      
      setInspectionData({
        total: inspections.length,
        completed,
        inProgress
      });
      
      // Process findings by severity
      const severityCounts = { low: 0, medium: 0, high: 0, critical: 0 };
      
      inspections.forEach(inspection => {
        if (inspection.findings && Array.isArray(inspection.findings)) {
          inspection.findings.forEach(finding => {
            if (finding.severity && severityCounts.hasOwnProperty(finding.severity.toLowerCase())) {
              severityCounts[finding.severity.toLowerCase()]++;
            }
          });
        }
      });
      
      setFindingsBySeverity(severityCounts);
      
      // Process inspections by month
      const monthlyData = processMonthlyData(inspections);
      setInspectionsByMonth(monthlyData);
      
      // Fetch templates for usage statistics
      const { data: templates, error: templatesError } = await supabase
        .from('templates')
        .select('id, title');
        
      if (templatesError) {
        throw templatesError;
      }
      
      // Calculate template usage
      const templateUsageData = calculateTemplateUsage(templates, inspections);
      setTemplateUsage(templateUsageData);
      
    } catch (error) {
      console.error('Error fetching analytics data:', error);
    } finally {
      setLoading(false);
    }
  }

  function getDateFilter(timeframe) {
    const now = new Date();
    
    switch(timeframe) {
      case '30days':
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(now.getDate() - 30);
        return thirtyDaysAgo.toISOString();
      case '90days':
        const ninetyDaysAgo = new Date();
        ninetyDaysAgo.setDate(now.getDate() - 90);
        return ninetyDaysAgo.toISOString();
      case 'year':
        const oneYearAgo = new Date();
        oneYearAgo.setFullYear(now.getFullYear() - 1);
        return oneYearAgo.toISOString();
      default:
        return null; // All time
    }
  }

  function processMonthlyData(inspections) {
    const monthlyMap = {};
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    
    inspections.forEach(inspection => {
      const date = new Date(inspection.created_at);
      const monthYear = `${monthNames[date.getMonth()]} ${date.getFullYear()}`;
      
      if (!monthlyMap[monthYear]) {
        monthlyMap[monthYear] = { total: 0, completed: 0 };
      }
      
      monthlyMap[monthYear].total++;
      
      if (inspection.status.toLowerCase() === 'completed') {
        monthlyMap[monthYear].completed++;
      }
    });
    
    // Convert to array and sort by date
    return Object.entries(monthlyMap)
      .map(([label, data]) => ({ label, ...data }))
      .sort((a, b) => {
        const [aMonth, aYear] = a.label.split(' ');
        const [bMonth, bYear] = b.label.split(' ');
        
        if (aYear !== bYear) {
          return parseInt(aYear) - parseInt(bYear);
        }
        
        return monthNames.indexOf(aMonth) - monthNames.indexOf(bMonth);
      });
  }

  function calculateTemplateUsage(templates, inspections) {
    const usageMap = {};
    
    // Initialize with all templates
    templates.forEach(template => {
      usageMap[template.id] = {
        id: template.id,
        title: template.title,
        count: 0
      };
    });
    
    // Count usage
    inspections.forEach(inspection => {
      if (inspection.template_id && usageMap[inspection.template_id]) {
        usageMap[inspection.template_id].count++;
      }
    });
    
    // Convert to array and sort by usage
    return Object.values(usageMap)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5); // Top 5 templates
  }

  const statusChartData = {
    labels: ['Completed', 'In Progress'],
    datasets: [
      {
        data: [inspectionData.completed, inspectionData.inProgress],
        backgroundColor: ['#10B981', '#3B82F6'],
        hoverBackgroundColor: ['#059669', '#2563EB']
      }
    ]
  };

  const severityChartData = {
    labels: ['Low', 'Medium', 'High', 'Critical'],
    datasets: [
      {
        label: 'Findings by Severity',
        data: [
          findingsBySeverity.low,
          findingsBySeverity.medium,
          findingsBySeverity.high,
          findingsBySeverity.critical
        ],
        backgroundColor: ['#93C5FD', '#FCD34D', '#F97316', '#EF4444'],
        borderWidth: 1
      }
    ]
  };

  const monthlyChartData = {
    labels: inspectionsByMonth.map(item => item.label),
    datasets: [
      {
        label: 'Total Inspections',
        data: inspectionsByMonth.map(item => item.total),
        borderColor: '#3B82F6',
        backgroundColor: 'rgba(59, 130, 246, 0.1)',
        tension: 0.4,
        fill: true
      },
      {
        label: 'Completed Inspections',
        data: inspectionsByMonth.map(item => item.completed),
        borderColor: '#10B981',
        backgroundColor: 'rgba(16, 185, 129, 0.1)',
        tension: 0.4,
        fill: true
      }
    ]
  };

  const templateUsageChartData = {
    labels: templateUsage.map(item => item.title),
    datasets: [
      {
        label: 'Template Usage',
        data: templateUsage.map(item => item.count),
        backgroundColor: [
          '#3B82F6',
          '#10B981',
          '#F97316',
          '#8B5CF6',
          '#EC4899'
        ],
        borderWidth: 1
      }
    ]
  };

  return (
    <ProtectedRoute requiredRole={['admin', 'inspector']}>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Analytics Dashboard</h1>
        
        <div className="mb-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Safety Inspection Analytics</h2>
            <div className="flex space-x-2">
              <button
                onClick={() => setTimeframeFilter('all')}
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  timeframeFilter === 'all' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
                }`}
              >
                All Time
              </button>
              <button
                onClick={() => setTimeframeFilter('30days')}
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  timeframeFilter === '30days' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
                }`}
              >
                Last 30 Days
              </button>
              <button
                onClick={() => setTimeframeFilter('90days')}
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  timeframeFilter === '90days' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
                }`}
              >
                Last 90 Days
              </button>
              <button
                onClick={() => setTimeframeFilter('year')}
                className={`px-3 py-1 rounded-full text-sm font-medium ${
                  timeframeFilter === 'year' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'
                }`}
              >
                Last Year
              </button>
            </div>
          </div>
        </div>
        
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">Inspection Summary</h3>
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <p className="text-gray-500 text-sm">Total Inspections</p>
                    <p className="text-3xl font-bold">{inspectionData.total}</p>
                  </div>
                  <div className="h-16 w-16">
                    <Pie data={statusChartData} options={{ plugins: { legend: { display: false } } }} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-blue-50 rounded p-3">
                    <p className="text-gray-500 text-sm">In Progress</p>
                    <p className="text-xl font-semibold text-blue-600">{inspectionData.inProgress}</p>
                  </div>
                  <div className="bg-green-50 rounded p-3">
                    <p className="text-gray-500 text-sm">Completed</p>
                    <p className="text-xl font-semibold text-green-600">{inspectionData.completed}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">Findings by Severity</h3>
                <div className="h-48">
                  <Bar 
                    data={severityChartData} 
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: {
                          display: false
                        }
                      },
                      scales: {
                        y: {
                          beginAtZero: true,
                          ticks: {
                            precision: 0
                          }
                        }
                      }
                    }} 
                  />
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="text-lg font-semibold mb-4">Top Templates</h3>
                <div className="h-48">
                  <Pie 
                    data={templateUsageChartData} 
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: {
                          position: 'right',
                          labels: {
                            boxWidth: 12,
                            font: {
                              size: 10
                            }
                          }
                        }
                      }
                    }} 
                  />
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6 mb-8">
              <h3 className="text-lg font-semibold mb-4">Inspection Trends</h3>
              <div className="h-80">
                <Line 
                  data={monthlyChartData} 
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'top'
                      }
                    },
                    scales: {
                      y: {
                        beginAtZero: true,
                        ticks: {
                          precision: 0
                        }
                      }
                    }
                  }} 
                />
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">Safety Insights</h3>
              <div className="space-y-4">
                {findingsBySeverity.critical > 0 && (
                  <div className="bg-red-50 border-l-4 border-red-500 p-4">
                    <p className="font-medium text-red-800">Critical Issues Detected</p>
                    <p className="text-red-700">There are {findingsBySeverity.critical} critical findings that require immediate attention.</p>
                  </div>
                )}
                
                {findingsBySeverity.high > 0 && (
                  <div className="bg-orange-50 border-l-4 border-orange-500 p-4">
                    <p className="font-medium text-orange-800">High Priority Issues</p>
                    <p className="text-orange-700">There are {findingsBySeverity.high} high severity findings that should be addressed soon.</p>
                  </div>
                )}
                
                {inspectionData.inProgress > 0 && (
                  <div className="bg-blue-50 border-l-4 border-blue-500 p-4">
                    <p className="font-medium text-blue-800">Pending Inspections</p>
                    <p className="text-blue-700">There are {inspectionData.inProgress} inspections in progress that need to be completed.</p>
                  </div>
                )}
                
                {inspectionData.total === 0 && (
                  <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4">
                    <p className="font-medium text-yellow-800">No Inspection Data</p>
                    <p className="text-yellow-700">Start creating inspections to see analytics and insights.</p>
                  </div>
                )}
              </div>
            </div>
          </>
        )}
        
        <div className="mt-8">
          <a href="/" className="text-blue-500 hover:text-blue-700">
            ← Back to Home
          </a>
        </div>
      </div>
    </ProtectedRoute>
  );
}
