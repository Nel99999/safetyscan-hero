'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/app/auth/context/AuthContext';
import ProtectedRoute from '@/app/auth/components/ProtectedRoute';
import Link from 'next/link';

export default function AIRecommendationsPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [inspections, setInspections] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [selectedInspection, setSelectedInspection] = useState(null);
  const [generatingRecommendations, setGeneratingRecommendations] = useState(false);

  useEffect(() => {
    if (user) {
      fetchInspections();
      fetchRecommendations();
    }
  }, [user]);

  async function fetchInspections() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('inspections')
        .select(`
          id,
          created_at,
          status,
          findings,
          template:template_id (title)
        `)
        .eq('status', 'completed')
        .order('created_at', { ascending: false })
        .limit(10);
        
      if (error) throw error;
      
      setInspections(data || []);
      
    } catch (error) {
      console.error('Error fetching inspections:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchRecommendations() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('ai_recommendations')
        .select(`
          id,
          created_at,
          inspection_id,
          recommendations,
          status,
          priority
        `)
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      setRecommendations(data || []);
      
    } catch (error) {
      console.error('Error fetching recommendations:', error);
    } finally {
      setLoading(false);
    }
  }

  async function generateRecommendations(inspectionId) {
    try {
      setGeneratingRecommendations(true);
      
      // Get the inspection data
      const { data: inspection, error: inspectionError } = await supabase
        .from('inspections')
        .select('*')
        .eq('id', inspectionId)
        .single();
        
      if (inspectionError) throw inspectionError;
      
      // In a real implementation, this would call an AI service
      // For this demo, we'll generate mock recommendations based on findings
      const mockRecommendations = generateMockRecommendations(inspection);
      
      // Save the recommendations to the database
      const { data, error } = await supabase
        .from('ai_recommendations')
        .insert({
          user_id: user?.id,
          inspection_id: inspectionId,
          recommendations: mockRecommendations.recommendations,
          status: 'active',
          priority: mockRecommendations.priority
        })
        .select();
        
      if (error) throw error;
      
      // Refresh recommendations
      fetchRecommendations();
      
    } catch (error) {
      console.error('Error generating recommendations:', error);
    } finally {
      setGeneratingRecommendations(false);
    }
  }

  function generateMockRecommendations(inspection) {
    // This is a mock function that would be replaced with actual AI processing
    const findings = inspection.findings || [];
    const criticalCount = findings.filter(f => f.severity === 'critical').length;
    const highCount = findings.filter(f => f.severity === 'high').length;
    
    let priority = 'low';
    if (criticalCount > 0) {
      priority = 'critical';
    } else if (highCount > 0) {
      priority = 'high';
    } else if (findings.length > 3) {
      priority = 'medium';
    }
    
    const recommendationItems = [];
    
    // Generate recommendations based on findings
    findings.forEach(finding => {
      if (finding.severity === 'critical' || finding.severity === 'high') {
        recommendationItems.push({
          title: `Address ${finding.severity} issue in ${finding.section}`,
          description: `The ${finding.question} issue requires immediate attention. Consider implementing a corrective action plan within 24-48 hours.`,
          timeframe: finding.severity === 'critical' ? '24 hours' : '1 week',
          type: 'corrective'
        });
      }
    });
    
    // Add preventive recommendations
    if (findings.length > 0) {
      recommendationItems.push({
        title: 'Implement regular inspection schedule',
        description: 'Based on the findings, we recommend implementing a regular inspection schedule to catch issues before they become critical.',
        timeframe: '1 month',
        type: 'preventive'
      });
      
      recommendationItems.push({
        title: 'Conduct staff training',
        description: 'Consider additional staff training on safety procedures related to the identified issues.',
        timeframe: '2 weeks',
        type: 'preventive'
      });
    }
    
    // Add general recommendations if few specific ones
    if (recommendationItems.length < 3) {
      recommendationItems.push({
        title: 'Review safety protocols',
        description: 'Conduct a general review of safety protocols to ensure all procedures are up to date.',
        timeframe: '1 month',
        type: 'general'
      });
    }
    
    return {
      recommendations: recommendationItems,
      priority,
      summary: `${recommendationItems.length} recommendations generated based on ${findings.length} findings.`
    };
  }

  function getPriorityColor(priority) {
    switch(priority.toLowerCase()) {
      case 'critical':
        return 'bg-red-100 text-red-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  function getRecommendationTypeColor(type) {
    switch(type.toLowerCase()) {
      case 'corrective':
        return 'bg-red-100 text-red-800';
      case 'preventive':
        return 'bg-green-100 text-green-800';
      case 'general':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">AI-Powered Recommendations</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4">Safety Recommendations</h2>
              
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
                </div>
              ) : recommendations.length > 0 ? (
                <div className="space-y-6">
                  {recommendations.map((rec) => (
                    <div key={rec.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="font-semibold">Recommendations for Inspection #{rec.inspection_id}</h3>
                          <p className="text-gray-500 text-sm">
                            Generated on {new Date(rec.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <span className={`${getPriorityColor(rec.priority)} px-2 py-1 rounded-full text-xs font-medium`}>
                          {rec.priority.charAt(0).toUpperCase() + rec.priority.slice(1)} Priority
                        </span>
                      </div>
                      
                      <div className="space-y-4">
                        {rec.recommendations.map((item, index) => (
                          <div key={index} className="bg-gray-50 p-3 rounded">
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="font-medium">{item.title}</h4>
                              <span className={`${getRecommendationTypeColor(item.type)} px-2 py-1 rounded-full text-xs font-medium`}>
                                {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                              </span>
                            </div>
                            <p className="text-gray-600 text-sm mb-2">{item.description}</p>
                            <p className="text-gray-500 text-xs">Recommended timeframe: {item.timeframe}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                  <div className="flex">
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">
                        No recommendations found. Generate recommendations from a completed inspection.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div>
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4">Generate Recommendations</h2>
              <p className="text-gray-600 mb-4">
                Select a completed inspection to generate AI-powered safety recommendations:
              </p>
              
              {loading ? (
                <div className="flex justify-center items-center h-32">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
                </div>
              ) : inspections.length > 0 ? (
                <div className="space-y-4">
                  {inspections.map((inspection) => (
                    <div 
                      key={inspection.id} 
                      className={`border rounded-lg p-3 cursor-pointer hover:bg-gray-50 ${
                        selectedInspection === inspection.id ? 'border-blue-500 bg-blue-50' : ''
                      }`}
                      onClick={() => setSelectedInspection(inspection.id)}
                    >
                      <h3 className="font-medium">{inspection.template?.title || 'Unnamed Inspection'}</h3>
                      <p className="text-gray-500 text-sm">
                        Completed on {new Date(inspection.created_at).toLocaleDateString()}
                      </p>
                      <p className="text-gray-500 text-sm">
                        {inspection.findings?.length || 0} findings recorded
                      </p>
                    </div>
                  ))}
                  
                  <button
                    onClick={() => selectedInspection && generateRecommendations(selectedInspection)}
                    disabled={!selectedInspection || generatingRecommendations}
                    className="w-full bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
                  >
                    {generatingRecommendations ? 'Generating...' : 'Generate Recommendations'}
                  </button>
                </div>
              ) : (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                  <div className="flex">
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">
                        No completed inspections found. Complete an inspection first.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4">About AI Recommendations</h2>
              <div className="space-y-3 text-gray-600">
                <p>
                  Our AI-powered recommendation system analyzes your inspection findings to provide:
                </p>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Corrective actions for critical issues</li>
                  <li>Preventive measures to avoid future problems</li>
                  <li>Prioritized recommendations based on severity</li>
                  <li>Suggested timeframes for implementation</li>
                </ul>
                <p className="mt-3">
                  Recommendations are generated using machine learning models trained on industry best practices and safety standards.
                </p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <Link href="/" className="text-blue-500 hover:text-blue-700">
            ← Back to Dashboard
          </Link>
        </div>
      </div>
    </ProtectedRoute>
  );
}
