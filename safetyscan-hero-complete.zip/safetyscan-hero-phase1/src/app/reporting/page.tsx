'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/app/auth/context/AuthContext';
import ProtectedRoute from '@/app/auth/components/ProtectedRoute';
import Link from 'next/link';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

export default function ReportingPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [inspections, setInspections] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [selectedInspections, setSelectedInspections] = useState([]);
  const [reportFormat, setReportFormat] = useState('detailed');
  const [includeLogo, setIncludeLogo] = useState(true);
  const [includePhotos, setIncludePhotos] = useState(true);
  const [customHeader, setCustomHeader] = useState('');
  const [customFooter, setCustomFooter] = useState('');
  const [generatingReport, setGeneratingReport] = useState(false);
  const [reportSchedules, setReportSchedules] = useState([]);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [newSchedule, setNewSchedule] = useState({
    name: '',
    frequency: 'weekly',
    day_of_week: 'monday',
    recipients: '',
    template_id: '',
    report_format: 'detailed',
    include_photos: true
  });

  useEffect(() => {
    if (user) {
      fetchInspections();
      fetchTemplates();
      fetchReportSchedules();
    }
  }, [user]);

  async function fetchInspections() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('inspections')
        .select(`
          id,
          created_at,
          status,
          metadata,
          template:template_id (title)
        `)
        .eq('status', 'completed')
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      setInspections(data || []);
      
    } catch (error) {
      console.error('Error fetching inspections:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchTemplates() {
    try {
      const { data, error } = await supabase
        .from('templates')
        .select('id, title')
        .order('title');
        
      if (error) throw error;
      
      setTemplates(data || []);
      
    } catch (error) {
      console.error('Error fetching templates:', error);
    }
  }

  async function fetchReportSchedules() {
    try {
      const { data, error } = await supabase
        .from('report_schedules')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      setReportSchedules(data || []);
      
    } catch (error) {
      console.error('Error fetching report schedules:', error);
    }
  }

  async function generateReport() {
    if (selectedInspections.length === 0) return;
    
    try {
      setGeneratingReport(true);
      
      // In a real implementation, this would fetch detailed inspection data
      // and generate a proper PDF report. For this demo, we'll create a simple report.
      
      // Create a new PDF document
      const doc = new jsPDF();
      
      // Add company logo if selected
      if (includeLogo) {
        // This would add a logo image in a real implementation
        doc.setFontSize(22);
        doc.setTextColor(0, 102, 204);
        doc.text("SafetyScan Hero", 105, 20, { align: 'center' });
      }
      
      // Add custom header if provided
      if (customHeader) {
        doc.setFontSize(12);
        doc.setTextColor(0, 0, 0);
        doc.text(customHeader, 105, 30, { align: 'center' });
      }
      
      // Add report title
      doc.setFontSize(18);
      doc.setTextColor(0, 0, 0);
      doc.text(
        selectedInspections.length > 1 ? "Bulk Inspection Report" : "Inspection Report", 
        105, 
        40, 
        { align: 'center' }
      );
      
      // Add generation date
      doc.setFontSize(10);
      doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 105, 48, { align: 'center' });
      
      let yPosition = 60;
      
      // Add inspection details
      for (let i = 0; i < selectedInspections.length; i++) {
        const inspectionId = selectedInspections[i];
        const inspection = inspections.find(insp => insp.id === inspectionId);
        
        if (!inspection) continue;
        
        // Add inspection header
        doc.setFontSize(14);
        doc.setTextColor(0, 102, 204);
        doc.text(`Inspection #${inspection.id}: ${inspection.template?.title || 'Unnamed Inspection'}`, 20, yPosition);
        yPosition += 8;
        
        // Add inspection details
        doc.setFontSize(10);
        doc.setTextColor(0, 0, 0);
        doc.text(`Date: ${new Date(inspection.created_at).toLocaleDateString()}`, 20, yPosition);
        yPosition += 6;
        doc.text(`Location: ${inspection.metadata?.location || 'Not specified'}`, 20, yPosition);
        yPosition += 6;
        doc.text(`Status: ${inspection.status}`, 20, yPosition);
        yPosition += 6;
        
        // Add more details based on report format
        if (reportFormat === 'detailed') {
          // In a real implementation, this would add findings, photos, etc.
          doc.text(`This detailed report would include all findings, comments, and photos.`, 20, yPosition);
          yPosition += 6;
          
          if (includePhotos) {
            doc.text(`Photos would be included here in the actual implementation.`, 20, yPosition);
            yPosition += 6;
          }
        } else {
          doc.text(`This summary report includes only key information and statistics.`, 20, yPosition);
          yPosition += 6;
        }
        
        // Add separator between inspections
        if (i < selectedInspections.length - 1) {
          yPosition += 10;
          doc.setDrawColor(200, 200, 200);
          doc.line(20, yPosition, 190, yPosition);
          yPosition += 15;
          
          // Add a new page if needed
          if (yPosition > 250) {
            doc.addPage();
            yPosition = 20;
          }
        }
      }
      
      // Add custom footer if provided
      if (customFooter) {
        doc.setFontSize(10);
        doc.text(customFooter, 105, 280, { align: 'center' });
      }
      
      // Save the PDF
      doc.save(`inspection_report_${new Date().toISOString().slice(0,10)}.pdf`);
      
    } catch (error) {
      console.error('Error generating report:', error);
    } finally {
      setGeneratingReport(false);
    }
  }

  async function createReportSchedule() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('report_schedules')
        .insert({
          user_id: user?.id,
          name: newSchedule.name,
          frequency: newSchedule.frequency,
          day_of_week: newSchedule.day_of_week,
          recipients: newSchedule.recipients.split(',').map(email => email.trim()),
          template_id: parseInt(newSchedule.template_id),
          report_format: newSchedule.report_format,
          include_photos: newSchedule.include_photos,
          next_generation_date: calculateNextDate(newSchedule.frequency, newSchedule.day_of_week)
        })
        .select();
        
      if (error) throw error;
      
      // Reset form and close modal
      setNewSchedule({
        name: '',
        frequency: 'weekly',
        day_of_week: 'monday',
        recipients: '',
        template_id: '',
        report_format: 'detailed',
        include_photos: true
      });
      
      setShowScheduleModal(false);
      
      // Refresh schedules
      fetchReportSchedules();
      
    } catch (error) {
      console.error('Error creating report schedule:', error);
    } finally {
      setLoading(false);
    }
  }

  async function deleteReportSchedule(id) {
    try {
      const { error } = await supabase
        .from('report_schedules')
        .delete()
        .eq('id', id);
        
      if (error) throw error;
      
      // Refresh schedules
      fetchReportSchedules();
      
    } catch (error) {
      console.error('Error deleting report schedule:', error);
    }
  }

  function calculateNextDate(frequency, dayOfWeek) {
    const date = new Date();
    
    switch(frequency) {
      case 'daily':
        // Next day
        date.setDate(date.getDate() + 1);
        break;
        
      case 'weekly':
        // Next occurrence of the specified day of week
        const days = {
          'sunday': 0,
          'monday': 1,
          'tuesday': 2,
          'wednesday': 3,
          'thursday': 4,
          'friday': 5,
          'saturday': 6
        };
        
        const targetDay = days[dayOfWeek.toLowerCase()];
        const currentDay = date.getDay();
        const daysToAdd = (targetDay + 7 - currentDay) % 7;
        
        date.setDate(date.getDate() + (daysToAdd === 0 ? 7 : daysToAdd));
        break;
        
      case 'monthly':
        // Next month, same day
        date.setMonth(date.getMonth() + 1);
        break;
        
      default:
        // Default to weekly
        date.setDate(date.getDate() + 7);
    }
    
    return date.toISOString();
  }

  function formatFrequency(frequency, dayOfWeek) {
    switch(frequency) {
      case 'daily':
        return 'Daily';
      case 'weekly':
        return `Weekly on ${dayOfWeek.charAt(0).toUpperCase() + dayOfWeek.slice(1)}s`;
      case 'monthly':
        return 'Monthly';
      default:
        return frequency;
    }
  }

  function handleInputChange(e) {
    const { name, value, type, checked } = e.target;
    setNewSchedule({
      ...newSchedule,
      [name]: type === 'checkbox' ? checked : value
    });
  }

  function toggleInspectionSelection(id) {
    if (selectedInspections.includes(id)) {
      setSelectedInspections(selectedInspections.filter(inspId => inspId !== id));
    } else {
      setSelectedInspections([...selectedInspections, id]);
    }
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Enhanced Reporting</h1>
          <div className="flex space-x-2">
            <button
              onClick={() => setShowScheduleModal(true)}
              className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
            >
              Schedule Reports
            </button>
            <button
              onClick={generateReport}
              disabled={selectedInspections.length === 0 || generatingReport}
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
            >
              {generatingReport ? 'Generating...' : 'Generate Report'}
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4">Select Inspections</h2>
              
              {loading ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
                </div>
              ) : inspections.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Select
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Template
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Location
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {inspections.map((inspection) => (
                        <tr 
                          key={inspection.id}
                          className={selectedInspections.includes(inspection.id) ? 'bg-blue-50' : ''}
                        >
                          <td className="px-6 py-4 whitespace-nowrap">
                            <input
                              type="checkbox"
                              checked={selectedInspections.includes(inspection.id)}
                              onChange={() => toggleInspectionSelection(inspection.id)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                            />
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {new Date(inspection.created_at).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {inspection.template?.title || 'Unknown Template'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {inspection.metadata?.location || 'Not specified'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                              {inspection.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                  <div className="flex">
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">
                        No completed inspections found. Complete an inspection first.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4">Scheduled Reports</h2>
              
              {reportSchedules.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Name
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Frequency
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Next Generation
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Recipients
                        </th>
                        <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {reportSchedules.map((schedule) => (
                        <tr key={schedule.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {schedule.name}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {formatFrequency(schedule.frequency, schedule.day_of_week)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {new Date(schedule.next_generation_date).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {schedule.recipients.join(', ')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <button
                              onClick={() => deleteReportSchedule(schedule.id)}
                              className="text-red-500 hover:text-red-700"
                            >
                              Delete
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                  <div className="flex">
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">
                        No scheduled reports found. Create a schedule to automate report generation.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div>
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4">Report Options</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Report Format
                  </label>
                  <select
                    value={reportFormat}
                    onChange={(e) => setReportFormat(e.target.value)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    <option value="detailed">Detailed Report</option>
                    <option value="summary">Summary Report</option>
                  </select>
                </div>
                
                <div>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={includeLogo}
                      onChange={(e) => setIncludeLogo(e.target.checked)}
                      className="mr-2"
                    />
                    <span className="text-gray-700">Include Company Logo</span>
                  </label>
                </div>
                
                <div>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      checked={includePhotos}
                      onChange={(e) => setIncludePhotos(e.target.checked)}
                      className="mr-2"
                    />
                    <span className="text-gray-700">Include Photos</span>
                  </label>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Custom Header
                  </label>
                  <input
                    type="text"
                    value={customHeader}
                    onChange={(e) => setCustomHeader(e.target.value)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter custom header text"
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Custom Footer
                  </label>
                  <input
                    type="text"
                    value={customFooter}
                    onChange={(e) => setCustomFooter(e.target.value)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter custom footer text"
                  />
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4">Report Features</h2>
              
              <div className="space-y-3">
                <div className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <h3 className="font-medium">Custom Templates</h3>
                    <p className="text-sm text-gray-500">Personalize report layouts and branding</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <h3 className="font-medium">Bulk Reporting</h3>
                    <p className="text-sm text-gray-500">Generate reports for multiple inspections at once</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <h3 className="font-medium">Scheduled Reports</h3>
                    <p className="text-sm text-gray-500">Automate report generation and distribution</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <h3 className="font-medium">Multiple Formats</h3>
                    <p className="text-sm text-gray-500">Export as PDF, CSV, or Excel</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <div>
                    <h3 className="font-medium">Direct Sharing</h3>
                    <p className="text-sm text-gray-500">Email reports directly to stakeholders</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <Link href="/" className="text-blue-500 hover:text-blue-700">
            ← Back to Dashboard
          </Link>
        </div>
        
        {/* Schedule Report Modal */}
        {showScheduleModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h3 className="text-xl font-semibold mb-4">Schedule Report</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Schedule Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={newSchedule.name}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter schedule name"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Template
                  </label>
                  <select
                    name="template_id"
                    value={newSchedule.template_id}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    required
                  >
                    <option value="">Select a template</option>
                    {templates.map(template => (
                      <option key={template.id} value={template.id}>
                        {template.title}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Frequency
                  </label>
                  <select
                    name="frequency"
                    value={newSchedule.frequency}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                  </select>
                </div>
                
                {newSchedule.frequency === 'weekly' && (
                  <div>
                    <label className="block text-gray-700 text-sm font-bold mb-2">
                      Day of Week
                    </label>
                    <select
                      name="day_of_week"
                      value={newSchedule.day_of_week}
                      onChange={handleInputChange}
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    >
                      <option value="monday">Monday</option>
                      <option value="tuesday">Tuesday</option>
                      <option value="wednesday">Wednesday</option>
                      <option value="thursday">Thursday</option>
                      <option value="friday">Friday</option>
                      <option value="saturday">Saturday</option>
                      <option value="sunday">Sunday</option>
                    </select>
                  </div>
                )}
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Recipients (comma separated)
                  </label>
                  <input
                    type="text"
                    name="recipients"
                    value={newSchedule.recipients}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="email1@example.com, email2@example.com"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Report Format
                  </label>
                  <select
                    name="report_format"
                    value={newSchedule.report_format}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    <option value="detailed">Detailed Report</option>
                    <option value="summary">Summary Report</option>
                  </select>
                </div>
                
                <div>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="include_photos"
                      checked={newSchedule.include_photos}
                      onChange={handleInputChange}
                      className="mr-2"
                    />
                    <span className="text-gray-700">Include Photos</span>
                  </label>
                </div>
              </div>
              
              <div className="flex justify-end mt-6 space-x-2">
                <button
                  onClick={() => setShowScheduleModal(false)}
                  className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={createReportSchedule}
                  disabled={!newSchedule.name || !newSchedule.template_id || !newSchedule.recipients}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
                >
                  Create Schedule
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}
