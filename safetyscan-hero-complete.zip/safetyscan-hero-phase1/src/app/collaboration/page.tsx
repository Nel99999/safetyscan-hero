'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/app/auth/context/AuthContext';
import ProtectedRoute from '@/app/auth/components/ProtectedRoute';
import Link from 'next/link';

export default function CollaborationPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [teams, setTeams] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [comments, setComments] = useState([]);
  const [users, setUsers] = useState([]);
  const [showCreateTeamModal, setShowCreateTeamModal] = useState(false);
  const [showCreateTaskModal, setShowCreateTaskModal] = useState(false);
  const [newTeam, setNewTeam] = useState({
    name: '',
    description: '',
    members: []
  });
  const [newTask, setNewTask] = useState({
    title: '',
    description: '',
    due_date: '',
    priority: 'medium',
    assignee: '',
    related_inspection: ''
  });
  const [newComment, setNewComment] = useState('');
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [inspections, setInspections] = useState([]);
  const [activities, setActivities] = useState([]);

  useEffect(() => {
    if (user) {
      fetchTeams();
      fetchTasks();
      fetchUsers();
      fetchInspections();
      fetchActivities();
    }
  }, [user]);

  useEffect(() => {
    if (selectedTeam) {
      fetchTeamComments(selectedTeam);
    }
  }, [selectedTeam]);

  async function fetchTeams() {
    try {
      setLoading(true);
      
      // Fetch teams the user is a member of
      const { data, error } = await supabase
        .from('teams')
        .select(`
          id,
          name,
          description,
          created_at,
          created_by,
          members
        `)
        .contains('members', [user?.id])
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      setTeams(data || []);
      
      // Set the first team as selected if available
      if (data && data.length > 0 && !selectedTeam) {
        setSelectedTeam(data[0].id);
      }
      
    } catch (error) {
      console.error('Error fetching teams:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchTasks() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('tasks')
        .select(`
          id,
          title,
          description,
          created_at,
          due_date,
          priority,
          status,
          assignee,
          created_by,
          related_inspection,
          assignee_user:assignee (full_name, email),
          creator:created_by (full_name, email)
        `)
        .or(`assignee.eq.${user?.id},created_by.eq.${user?.id}`)
        .order('due_date', { ascending: true });
        
      if (error) throw error;
      
      setTasks(data || []);
      
    } catch (error) {
      console.error('Error fetching tasks:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchTeamComments(teamId) {
    try {
      const { data, error } = await supabase
        .from('comments')
        .select(`
          id,
          content,
          created_at,
          user_id,
          team_id,
          user:user_id (full_name, email)
        `)
        .eq('team_id', teamId)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      setComments(data || []);
      
    } catch (error) {
      console.error('Error fetching comments:', error);
    }
  }

  async function fetchUsers() {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('id, full_name, email')
        .order('full_name');
        
      if (error) throw error;
      
      setUsers(data || []);
      
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  }

  async function fetchInspections() {
    try {
      const { data, error } = await supabase
        .from('inspections')
        .select(`
          id,
          created_at,
          status,
          template:template_id (title)
        `)
        .eq('status', 'completed')
        .order('created_at', { ascending: false })
        .limit(10);
        
      if (error) throw error;
      
      setInspections(data || []);
      
    } catch (error) {
      console.error('Error fetching inspections:', error);
    }
  }

  async function fetchActivities() {
    try {
      const { data, error } = await supabase
        .from('activities')
        .select(`
          id,
          action,
          entity_type,
          entity_id,
          created_at,
          user_id,
          metadata,
          user:user_id (full_name, email)
        `)
        .order('created_at', { ascending: false })
        .limit(20);
        
      if (error) throw error;
      
      setActivities(data || []);
      
    } catch (error) {
      console.error('Error fetching activities:', error);
    }
  }

  async function createTeam() {
    try {
      setLoading(true);
      
      // Ensure creator is included in members
      const members = [...new Set([...newTeam.members, user?.id])];
      
      const { data, error } = await supabase
        .from('teams')
        .insert({
          name: newTeam.name,
          description: newTeam.description,
          created_by: user?.id,
          members
        })
        .select();
        
      if (error) throw error;
      
      // Log activity
      await logActivity('created', 'team', data[0].id, { team_name: newTeam.name });
      
      // Reset form and close modal
      setNewTeam({
        name: '',
        description: '',
        members: []
      });
      
      setShowCreateTeamModal(false);
      
      // Refresh teams
      fetchTeams();
      
    } catch (error) {
      console.error('Error creating team:', error);
    } finally {
      setLoading(false);
    }
  }

  async function createTask() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('tasks')
        .insert({
          title: newTask.title,
          description: newTask.description,
          due_date: newTask.due_date,
          priority: newTask.priority,
          status: 'open',
          assignee: newTask.assignee,
          created_by: user?.id,
          related_inspection: newTask.related_inspection ? parseInt(newTask.related_inspection) : null
        })
        .select();
        
      if (error) throw error;
      
      // Log activity
      await logActivity('created', 'task', data[0].id, { 
        task_title: newTask.title,
        assignee: newTask.assignee
      });
      
      // Reset form and close modal
      setNewTask({
        title: '',
        description: '',
        due_date: '',
        priority: 'medium',
        assignee: '',
        related_inspection: ''
      });
      
      setShowCreateTaskModal(false);
      
      // Refresh tasks
      fetchTasks();
      
    } catch (error) {
      console.error('Error creating task:', error);
    } finally {
      setLoading(false);
    }
  }

  async function addComment() {
    if (!newComment.trim() || !selectedTeam) return;
    
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('comments')
        .insert({
          content: newComment,
          user_id: user?.id,
          team_id: selectedTeam
        })
        .select();
        
      if (error) throw error;
      
      // Log activity
      await logActivity('commented', 'team', selectedTeam, { comment_id: data[0].id });
      
      // Reset form
      setNewComment('');
      
      // Refresh comments
      fetchTeamComments(selectedTeam);
      
    } catch (error) {
      console.error('Error adding comment:', error);
    } finally {
      setLoading(false);
    }
  }

  async function updateTaskStatus(taskId, newStatus) {
    try {
      const { error } = await supabase
        .from('tasks')
        .update({ status: newStatus })
        .eq('id', taskId);
        
      if (error) throw error;
      
      // Log activity
      await logActivity('updated', 'task', taskId, { status: newStatus });
      
      // Refresh tasks
      fetchTasks();
      
    } catch (error) {
      console.error('Error updating task status:', error);
    }
  }

  async function logActivity(action, entityType, entityId, metadata = {}) {
    try {
      await supabase
        .from('activities')
        .insert({
          action,
          entity_type: entityType,
          entity_id: entityId,
          user_id: user?.id,
          metadata
        });
    } catch (error) {
      console.error('Error logging activity:', error);
    }
  }

  function handleTeamMemberToggle(userId) {
    const currentMembers = [...newTeam.members];
    
    if (currentMembers.includes(userId)) {
      // Remove member if already selected
      setNewTeam({
        ...newTeam,
        members: currentMembers.filter(id => id !== userId)
      });
    } else {
      // Add member if not already selected
      setNewTeam({
        ...newTeam,
        members: [...currentMembers, userId]
      });
    }
  }

  function handleInputChange(e, formSetter, formState) {
    const { name, value } = e.target;
    formSetter({
      ...formState,
      [name]: value
    });
  }

  function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString();
  }

  function formatDateTime(dateString) {
    return new Date(dateString).toLocaleString();
  }

  function getPriorityColor(priority) {
    switch(priority.toLowerCase()) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  function getStatusColor(status) {
    switch(status.toLowerCase()) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'in_progress':
        return 'bg-blue-100 text-blue-800';
      case 'open':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  function formatActivityAction(action, entityType) {
    return `${action} ${entityType}`;
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Collaboration</h1>
          <div className="flex space-x-2">
            <button
              onClick={() => setShowCreateTaskModal(true)}
              className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
            >
              Create Task
            </button>
            <button
              onClick={() => setShowCreateTeamModal(true)}
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            >
              Create Team
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4">Your Tasks</h2>
              
              {loading && tasks.length === 0 ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
                </div>
              ) : tasks.length > 0 ? (
                <div className="space-y-4">
                  {tasks.map((task) => (
                    <div key={task.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-semibold">{task.title}</h3>
                          <p className="text-gray-500 text-sm">
                            Assigned to: {task.assignee_user?.full_name || 'Unassigned'} | 
                            Due: {task.due_date ? formatDate(task.due_date) : 'No due date'}
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(task.priority)}`}>
                            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                          </span>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(task.status)}`}>
                            {task.status.replace('_', ' ').charAt(0).toUpperCase() + task.status.replace('_', ' ').slice(1)}
                          </span>
                        </div>
                      </div>
                      
                      <p className="text-gray-700 text-sm mb-3">{task.description}</p>
                      
                      <div className="flex justify-between items-center">
                        <div className="text-xs text-gray-500">
                          Created by {task.creator?.full_name || 'Unknown'} on {formatDate(task.created_at)}
                        </div>
                        <div className="flex space-x-2">
                          {task.status !== 'completed' && (
                            <button
                              onClick={() => updateTaskStatus(task.id, 'in_progress')}
                              className={`text-xs px-2 py-1 rounded ${task.status === 'in_progress' ? 'bg-blue-200 text-blue-800' : 'bg-gray-200 text-gray-800'}`}
                            >
                              In Progress
                            </button>
                          )}
                          {task.status !== 'completed' && (
                            <button
                              onClick={() => updateTaskStatus(task.id, 'completed')}
                              className="text-xs px-2 py-1 rounded bg-green-200 text-green-800"
                            >
                              Complete
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                  <div className="flex">
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">
                        No tasks found. Create a task to get started.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4">Team Discussion</h2>
              
              {teams.length > 0 ? (
                <div className="mb-4">
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Select Team
                  </label>
                  <select
                    value={selectedTeam || ''}
                    onChange={(e) => setSelectedTeam(e.target.value)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    {teams.map(team => (
                      <option key={team.id} value={team.id}>
                        {team.name}
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                  <div className="flex">
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">
                        No teams found. Create a team to start discussions.
                      </p>
                    </div>
                  </div>
                </div>
              )}
              
              {selectedTeam && (
                <>
                  <div className="mb-4">
                    <div className="flex">
                      <input
                        type="text"
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        className="shadow appearance-none border rounded-l w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        placeholder="Type your comment..."
                      />
                      <button
                        onClick={addComment}
                        disabled={!newComment.trim()}
                        className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-r disabled:opacity-50"
                      >
                        Post
                      </button>
                    </div>
                  </div>
                  
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {comments.map((comment) => (
                      <div key={comment.id} className="border rounded-lg p-3">
                        <div className="flex justify-between items-start mb-2">
                          <div className="font-medium">{comment.user?.full_name || 'Unknown User'}</div>
                          <div className="text-xs text-gray-500">{formatDateTime(comment.created_at)}</div>
                        </div>
                        <p className="text-gray-700">{comment.content}</p>
                      </div>
                    ))}
                    
                    {comments.length === 0 && (
                      <div className="text-center text-gray-500 py-4">
                        No comments yet. Start the conversation!
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
          
          <div>
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4">Your Teams</h2>
              
              {loading && teams.length === 0 ? (
                <div className="flex justify-center items-center h-32">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-blue-500"></div>
                </div>
              ) : teams.length > 0 ? (
                <div className="space-y-3">
                  {teams.map((team) => (
                    <div 
                      key={team.id} 
                      className={`border rounded-lg p-3 cursor-pointer hover:bg-gray-50 ${
                        selectedTeam === team.id ? 'border-blue-500 bg-blue-50' : ''
                      }`}
                      onClick={() => setSelectedTeam(team.id)}
                    >
                      <h3 className="font-medium">{team.name}</h3>
                      <p className="text-gray-500 text-sm">{team.description}</p>
                      <p className="text-gray-500 text-xs mt-1">
                        {team.members?.length || 0} members | Created {formatDate(team.created_at)}
                      </p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                  <div className="flex">
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">
                        No teams found. Create a team to collaborate with others.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
              
              {activities.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {activities.map((activity) => (
                    <div key={activity.id} className="flex items-start space-x-3 py-2 border-b border-gray-100">
                      <div className="bg-blue-100 p-2 rounded-full">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                      </div>
                      <div>
                        <p className="text-sm">
                          <span className="font-medium">{activity.user?.full_name || 'Unknown User'}</span>
                          {' '}
                          {formatActivityAction(activity.action, activity.entity_type)}
                        </p>
                        <p className="text-xs text-gray-500">{formatDateTime(activity.created_at)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center text-gray-500 py-4">
                  No recent activity.
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <Link href="/" className="text-blue-500 hover:text-blue-700">
            ← Back to Dashboard
          </Link>
        </div>
        
        {/* Create Team Modal */}
        {showCreateTeamModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h3 className="text-xl font-semibold mb-4">Create Team</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Team Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={newTeam.name}
                    onChange={(e) => handleInputChange(e, setNewTeam, newTeam)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter team name"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={newTeam.description}
                    onChange={(e) => handleInputChange(e, setNewTeam, newTeam)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter team description"
                    rows={3}
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Team Members
                  </label>
                  <div className="max-h-40 overflow-y-auto border rounded p-2">
                    {users.map(user => (
                      <label key={user.id} className="flex items-center py-1">
                        <input
                          type="checkbox"
                          checked={newTeam.members.includes(user.id)}
                          onChange={() => handleTeamMemberToggle(user.id)}
                          className="mr-2"
                        />
                        <span>{user.full_name} ({user.email})</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end mt-6 space-x-2">
                <button
                  onClick={() => setShowCreateTeamModal(false)}
                  className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={createTeam}
                  disabled={!newTeam.name}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
                >
                  Create Team
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Create Task Modal */}
        {showCreateTaskModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h3 className="text-xl font-semibold mb-4">Create Task</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Task Title
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={newTask.title}
                    onChange={(e) => handleInputChange(e, setNewTask, newTask)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter task title"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={newTask.description}
                    onChange={(e) => handleInputChange(e, setNewTask, newTask)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter task description"
                    rows={3}
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Due Date
                  </label>
                  <input
                    type="date"
                    name="due_date"
                    value={newTask.due_date}
                    onChange={(e) => handleInputChange(e, setNewTask, newTask)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Priority
                  </label>
                  <select
                    name="priority"
                    value={newTask.priority}
                    onChange={(e) => handleInputChange(e, setNewTask, newTask)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Assignee
                  </label>
                  <select
                    name="assignee"
                    value={newTask.assignee}
                    onChange={(e) => handleInputChange(e, setNewTask, newTask)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    <option value="">Select assignee</option>
                    {users.map(user => (
                      <option key={user.id} value={user.id}>
                        {user.full_name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Related Inspection (optional)
                  </label>
                  <select
                    name="related_inspection"
                    value={newTask.related_inspection}
                    onChange={(e) => handleInputChange(e, setNewTask, newTask)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    <option value="">None</option>
                    {inspections.map(inspection => (
                      <option key={inspection.id} value={inspection.id}>
                        {inspection.template?.title || 'Unnamed'} ({formatDate(inspection.created_at)})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div className="flex justify-end mt-6 space-x-2">
                <button
                  onClick={() => setShowCreateTaskModal(false)}
                  className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={createTask}
                  disabled={!newTask.title}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
                >
                  Create Task
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}
