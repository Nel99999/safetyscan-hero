'use client';

import { useState, useEffect, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { useAuth } from '../../auth/context/AuthContext';
import ProtectedRoute from '../../auth/components/ProtectedRoute';

interface Inspection {
  id: number;
  created_at: string;
  template_id: number;
  status: string;
  metadata: {
    location: string;
    inspector: string;
    notes: string;
  };
  findings: Finding[];
  template?: {
    title: string;
    description: string;
    sections?: any[];
  };
  user_id: string | null;
}

interface Finding {
  id: string;
  section: string;
  question: string;
  response: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  notes: string;
  photo_url?: string;
}

export default function EditInspectionPage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const [inspection, setInspection] = useState<Inspection | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [findings, setFindings] = useState<Finding[]>([]);
  const [currentPhotoSection, setCurrentPhotoSection] = useState<string | null>(null);
  const [currentPhotoQuestion, setCurrentPhotoQuestion] = useState<string | null>(null);
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (params.id) {
      fetchInspection(parseInt(params.id as string));
    }
  }, [params.id]);

  async function fetchInspection(inspectionId: number) {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('inspections')
        .select(`
          *,
          template:template_id (title, description, sections)
        `)
        .eq('id', inspectionId)
        .single();

      if (error) {
        throw error;
      }

      if (data) {
        setInspection(data);
        setFindings(data.findings || []);
      }
    } catch (error) {
      console.error('Error fetching inspection:', error);
    } finally {
      setLoading(false);
    }
  }

  async function saveInspection() {
    if (!inspection) return;
    
    try {
      setSaving(true);
      
      const { error } = await supabase
        .from('inspections')
        .update({ 
          findings: findings,
          user_id: user?.id || null
        })
        .eq('id', inspection.id);

      if (error) {
        throw error;
      }

      router.push(`/inspections/${inspection.id}`);
    } catch (error) {
      console.error('Error saving inspection:', error);
    } finally {
      setSaving(false);
    }
  }

  function updateFinding(index: number, updates: Partial<Finding>) {
    const updatedFindings = [...findings];
    updatedFindings[index] = { ...updatedFindings[index], ...updates };
    setFindings(updatedFindings);
  }

  function addFinding() {
    const newFinding: Finding = {
      id: Date.now().toString(),
      section: '',
      question: '',
      response: '',
      severity: 'low',
      notes: ''
    };
    
    setFindings([...findings, newFinding]);
  }

  function removeFinding(index: number) {
    const updatedFindings = [...findings];
    updatedFindings.splice(index, 1);
    setFindings(updatedFindings);
  }

  function openPhotoUpload(section: string, question: string) {
    setCurrentPhotoSection(section);
    setCurrentPhotoQuestion(question);
    setShowPhotoModal(true);
  }

  async function handlePhotoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    if (!e.target.files || e.target.files.length === 0 || !inspection) {
      return;
    }
    
    try {
      setSaving(true);
      
      const file = e.target.files[0];
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}.${fileExt}`;
      const filePath = `${user?.id}/${inspection.id}/${fileName}`;
      
      const { error: uploadError } = await supabase.storage
        .from('findings')
        .upload(filePath, file);
        
      if (uploadError) {
        throw uploadError;
      }
      
      const { data: publicUrlData } = supabase.storage
        .from('findings')
        .getPublicUrl(filePath);
        
      // Find the finding that matches the current section and question
      const findingIndex = findings.findIndex(
        f => f.section === currentPhotoSection && f.question === currentPhotoQuestion
      );
      
      if (findingIndex !== -1) {
        updateFinding(findingIndex, { photo_url: publicUrlData.publicUrl });
      }
      
      setShowPhotoModal(false);
    } catch (error) {
      console.error('Error uploading photo:', error);
    } finally {
      setSaving(false);
    }
  }

  function getSeverityColor(severity: string) {
    switch(severity.toLowerCase()) {
      case 'low':
        return 'bg-blue-100 text-blue-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'critical':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  if (loading && !inspection) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>;
  }

  if (!inspection) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
          <p>Inspection not found.</p>
        </div>
        <Link href="/inspections" className="text-blue-500 hover:text-blue-700">
          ← Back to Inspections
        </Link>
      </div>
    );
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">Edit Inspection</h1>
            <div className="flex space-x-2">
              <Link
                href={`/inspections/${inspection.id}`}
                className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
              >
                Cancel
              </Link>
              <button
                onClick={saveInspection}
                disabled={saving}
                className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex justify-between">
              <div>
                <h2 className="text-xl font-semibold mb-2">
                  Template: {inspection.template?.title}
                </h2>
                <p className="text-gray-600 mb-4">{inspection.template?.description}</p>
              </div>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Findings</h3>
              <button
                onClick={addFinding}
                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-3 rounded text-sm"
              >
                Add Finding
              </button>
            </div>
            
            {findings.length === 0 ? (
              <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4">
                <p>No findings recorded for this inspection. Add findings to document issues.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {findings.map((finding, index) => (
                  <div key={finding.id || index} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-4">
                      <h4 className="font-semibold">Finding {index + 1}</h4>
                      <button
                        onClick={() => removeFinding(index)}
                        className="text-red-500 hover:text-red-700"
                      >
                        Remove
                      </button>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-gray-700 text-sm font-bold mb-2">
                          Section
                        </label>
                        <input
                          type="text"
                          value={finding.section}
                          onChange={(e) => updateFinding(index, { section: e.target.value })}
                          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                          placeholder="Section name"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-700 text-sm font-bold mb-2">
                          Question
                        </label>
                        <input
                          type="text"
                          value={finding.question}
                          onChange={(e) => updateFinding(index, { question: e.target.value })}
                          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                          placeholder="Question text"
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div>
                        <label className="block text-gray-700 text-sm font-bold mb-2">
                          Response
                        </label>
                        <input
                          type="text"
                          value={finding.response}
                          onChange={(e) => updateFinding(index, { response: e.target.value })}
                          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                          placeholder="Response"
                        />
                      </div>
                      <div>
                        <label className="block text-gray-700 text-sm font-bold mb-2">
                          Severity
                        </label>
                        <select
                          value={finding.severity}
                          onChange={(e) => updateFinding(index, { severity: e.target.value as any })}
                          className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        >
                          <option value="low">Low</option>
                          <option value="medium">Medium</option>
                          <option value="high">High</option>
                          <option value="critical">Critical</option>
                        </select>
                      </div>
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-gray-700 text-sm font-bold mb-2">
                        Notes
                      </label>
                      <textarea
                        value={finding.notes}
                        onChange={(e) => updateFinding(index, { notes: e.target.value })}
                        className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                        placeholder="Additional notes"
                        rows={3}
                      />
                    </div>
                    
                    <div>
                      <label className="block text-gray-700 text-sm font-bold mb-2">
                        Photo Evidence
                      </label>
                      {finding.photo_url ? (
                        <div className="mb-2">
                          <img 
                            src={finding.photo_url} 
                            alt={`Finding ${index + 1}`} 
                            className="max-h-48 rounded border border-gray-300 mb-2"
                          />
                          <button
                            onClick={() => openPhotoUpload(finding.section, finding.question)}
                            className="text-blue-500 hover:text-blue-700 text-sm"
                          >
                            Replace Photo
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => openPhotoUpload(finding.section, finding.question)}
                          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-3 rounded text-sm"
                        >
                          Upload Photo
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        
        {/* Photo Upload Modal */}
        {showPhotoModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h3 className="text-xl font-semibold mb-4">Upload Photo Evidence</h3>
              <p className="mb-4">Select a photo to upload:</p>
              
              <input
                type="file"
                ref={fileInputRef}
                accept="image/*"
                onChange={handlePhotoUpload}
                className="mb-4"
              />
              
              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => setShowPhotoModal(false)}
                  className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}
