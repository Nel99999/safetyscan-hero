'use client';

import { useState, useEffect, useRef } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { useAuth } from '../../auth/context/AuthContext';
import ProtectedRoute from '../../auth/components/ProtectedRoute';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface Inspection {
  id: number;
  created_at: string;
  template_id: number;
  status: string;
  metadata: {
    location: string;
    inspector: string;
    notes: string;
  };
  findings: Finding[];
  template?: {
    title: string;
    description: string;
    sections?: any[];
  };
  completed_at: string | null;
  signature_url: string | null;
  user_id: string | null;
}

interface Finding {
  id: string;
  section: string;
  question: string;
  response: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  notes: string;
  photo_url?: string;
}

export default function InspectionDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { user } = useAuth();
  const [inspection, setInspection] = useState<Inspection | null>(null);
  const [loading, setLoading] = useState(true);
  const [showSignatureModal, setShowSignatureModal] = useState(false);
  const [generatingPdf, setGeneratingPdf] = useState(false);
  const signatureCanvasRef = useRef<HTMLCanvasElement>(null);
  const reportRef = useRef<HTMLDivElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [signatureDataUrl, setSignatureDataUrl] = useState<string | null>(null);

  useEffect(() => {
    if (params.id) {
      fetchInspection(parseInt(params.id as string));
    }
  }, [params.id]);

  async function fetchInspection(inspectionId: number) {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('inspections')
        .select(`
          *,
          template:template_id (title, description, sections)
        `)
        .eq('id', inspectionId)
        .single();

      if (error) {
        throw error;
      }

      if (data) {
        setInspection(data);
      }
    } catch (error) {
      console.error('Error fetching inspection:', error);
    } finally {
      setLoading(false);
    }
  }

  async function completeInspection() {
    if (!inspection) return;
    
    if (!signatureDataUrl) {
      setShowSignatureModal(true);
      return;
    }
    
    try {
      setLoading(true);
      
      // Upload signature if exists
      let signature_url = inspection.signature_url;
      if (signatureDataUrl) {
        const signatureFile = await dataURLtoFile(
          signatureDataUrl,
          `signature_${inspection.id}_${Date.now()}.png`
        );
        
        const { data: signatureData, error: signatureError } = await supabase.storage
          .from('signatures')
          .upload(`${user?.id}/${signatureFile.name}`, signatureFile);
          
        if (signatureError) {
          throw signatureError;
        }
        
        if (signatureData) {
          const { data: signatureUrl } = supabase.storage
            .from('signatures')
            .getPublicUrl(signatureData.path);
            
          signature_url = signatureUrl.publicUrl;
        }
      }
      
      const { error } = await supabase
        .from('inspections')
        .update({ 
          status: 'completed',
          completed_at: new Date().toISOString(),
          signature_url
        })
        .eq('id', inspection.id);

      if (error) {
        throw error;
      }

      // Refresh the inspection data
      fetchInspection(inspection.id);
      setShowSignatureModal(false);
    } catch (error) {
      console.error('Error completing inspection:', error);
    } finally {
      setLoading(false);
    }
  }
  
  async function dataURLtoFile(dataurl: string, filename: string): Promise<File> {
    const arr = dataurl.split(',');
    const mime = arr[0].match(/:(.*?);/)![1];
    const bstr = atob(arr[1]);
    let n = bstr.length;
    const u8arr = new Uint8Array(n);
    
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    
    return new File([u8arr], filename, { type: mime });
  }

  function startDrawing(e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) {
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    
    setIsDrawing(true);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.beginPath();
    
    // Get the correct position for both mouse and touch events
    const rect = canvas.getBoundingClientRect();
    const x = e.type.includes('mouse') 
      ? (e as React.MouseEvent).clientX - rect.left 
      : (e as React.TouchEvent).touches[0].clientX - rect.left;
    const y = e.type.includes('mouse') 
      ? (e as React.MouseEvent).clientY - rect.top 
      : (e as React.TouchEvent).touches[0].clientY - rect.top;
    
    ctx.moveTo(x, y);
  }

  function draw(e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) {
    if (!isDrawing) return;
    
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Get the correct position for both mouse and touch events
    const rect = canvas.getBoundingClientRect();
    const x = e.type.includes('mouse') 
      ? (e as React.MouseEvent).clientX - rect.left 
      : (e as React.TouchEvent).touches[0].clientX - rect.left;
    const y = e.type.includes('mouse') 
      ? (e as React.MouseEvent).clientY - rect.top 
      : (e as React.TouchEvent).touches[0].clientY - rect.top;
    
    ctx.lineTo(x, y);
    ctx.stroke();
  }

  function stopDrawing() {
    setIsDrawing(false);
    
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    
    setSignatureDataUrl(canvas.toDataURL());
  }

  function clearSignature() {
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureDataUrl(null);
  }

  async function generatePDF() {
    if (!inspection || !reportRef.current) return;
    
    try {
      setGeneratingPdf(true);
      
      const content = reportRef.current;
      const canvas = await html2canvas(content);
      const imgData = canvas.toDataURL('image/png');
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });
      
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`inspection_report_${inspection.id}.pdf`);
    } catch (error) {
      console.error('Error generating PDF:', error);
    } finally {
      setGeneratingPdf(false);
    }
  }

  function getSeverityColor(severity: string) {
    switch(severity.toLowerCase()) {
      case 'low':
        return 'bg-blue-100 text-blue-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'critical':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  if (loading && !inspection) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>;
  }

  if (!inspection) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
          <p>Inspection not found.</p>
        </div>
        <Link href="/inspections" className="text-blue-500 hover:text-blue-700">
          ← Back to Inspections
        </Link>
      </div>
    );
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">Inspection Details</h1>
            <div className="flex space-x-2">
              {inspection.status.toLowerCase() === 'in progress' && (
                <>
                  <button
                    onClick={completeInspection}
                    className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
                  >
                    Complete Inspection
                  </button>
                  <Link
                    href={`/inspections/${inspection.id}/edit`}
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                  >
                    Edit
                  </Link>
                </>
              )}
              {inspection.status.toLowerCase() === 'completed' && (
                <button
                  onClick={generatePDF}
                  disabled={generatingPdf}
                  className="bg-purple-500 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
                >
                  {generatingPdf ? 'Generating PDF...' : 'Download PDF Report'}
                </button>
              )}
            </div>
          </div>

          <div ref={reportRef}>
            <div className="mb-6">
              <div className="flex justify-between">
                <div>
                  <h2 className="text-xl font-semibold mb-2">
                    Template: {inspection.template?.title}
                  </h2>
                  <p className="text-gray-600 mb-4">{inspection.template?.description}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-500">
                    Date: {new Date(inspection.created_at).toLocaleDateString()}
                  </p>
                  <p className="text-sm text-gray-500 mt-1">
                    Status: 
                    <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${
                      inspection.status.toLowerCase() === 'completed' 
                        ? 'bg-green-100 text-green-800' 
                        : inspection.status.toLowerCase() === 'in progress'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {inspection.status}
                    </span>
                  </p>
                  {inspection.completed_at && (
                    <p className="text-sm text-gray-500 mt-1">
                      Completed: {new Date(inspection.completed_at).toLocaleDateString()}
                    </p>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <h3 className="text-lg font-semibold mb-2">Inspection Details</h3>
                <div className="bg-gray-50 p-4 rounded">
                  <p className="mb-2">
                    <span className="font-semibold">Location:</span> {inspection.metadata?.location || 'Not specified'}
                  </p>
                  <p className="mb-2">
                    <span className="font-semibold">Inspector:</span> {inspection.metadata?.inspector || 'Not specified'}
                  </p>
                  <p>
                    <span className="font-semibold">Notes:</span> {inspection.metadata?.notes || 'No notes provided'}
                  </p>
                </div>
              </div>
              
              {inspection.signature_url && (
                <div>
                  <h3 className="text-lg font-semibold mb-2">Inspector Signature</h3>
                  <div className="bg-gray-50 p-4 rounded">
                    <img 
                      src={inspection.signature_url} 
                      alt="Inspector Signature" 
                      className="max-h-32 border border-gray-300"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Findings</h3>
              {inspection.findings && inspection.findings.length > 0 ? (
                <div className="space-y-4">
                  {inspection.findings.map((finding, index) => (
                    <div key={finding.id || index} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-semibold">{finding.section}: {finding.question}</h4>
                          <p className="text-gray-600 mt-1">Response: {finding.response}</p>
                        </div>
                        <span className={`${getSeverityColor(finding.severity)} px-2 py-1 rounded-full text-xs font-medium`}>
                          {finding.severity.charAt(0).toUpperCase() + finding.severity.slice(1)} Severity
                        </span>
                      </div>
                      
                      {finding.notes && (
                        <div className="mt-2">
                          <p className="text-sm font-medium">Notes:</p>
                          <p className="text-gray-600">{finding.notes}</p>
                        </div>
                      )}
                      
                      {finding.photo_url && (
                        <div className="mt-3">
                          <p className="text-sm font-medium mb-1">Photo Evidence:</p>
                          <img 
                            src={finding.photo_url} 
                            alt={`Finding ${index + 1}`} 
                            className="max-h-48 rounded border border-gray-300"
                          />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4">
                  <p>No findings recorded for this inspection.</p>
                </div>
              )}
            </div>
          </div>

          <div className="mt-8">
            <Link href="/inspections" className="text-blue-500 hover:text-blue-700">
              ← Back to Inspections
            </Link>
          </div>
        </div>
        
        {/* Signature Modal */}
        {showSignatureModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h3 className="text-xl font-semibold mb-4">Inspector Signature</h3>
              <p className="mb-4">Please sign below to complete the inspection:</p>
              
              <div className="border border-gray-300 rounded mb-4">
                <canvas
                  ref={signatureCanvasRef}
                  width={500}
                  height={200}
                  className="w-full touch-none"
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                  onTouchStart={startDrawing}
                  onTouchMove={draw}
                  onTouchEnd={stopDrawing}
                ></canvas>
              </div>
              
              <div className="flex justify-between">
                <button
                  onClick={clearSignature}
                  className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                >
                  Clear
                </button>
                <div className="space-x-2">
                  <button
                    onClick={() => setShowSignatureModal(false)}
                    className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={completeInspection}
                    disabled={!signatureDataUrl}
                    className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
                  >
                    Complete Inspection
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}
