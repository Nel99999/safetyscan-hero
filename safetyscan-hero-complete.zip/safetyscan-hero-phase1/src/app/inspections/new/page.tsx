'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';

interface Template {
  id: number;
  title: string;
  description: string;
}

export default function NewInspectionPage({ 
  searchParams 
}: { 
  searchParams: { templateId?: string } 
}) {
  const router = useRouter();
  const [template, setTemplate] = useState<Template | null>(null);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    location: '',
    inspector: '',
    notes: ''
  });

  useEffect(() => {
    if (searchParams.templateId) {
      fetchTemplate(parseInt(searchParams.templateId));
    } else {
      setLoading(false);
    }
  }, [searchParams.templateId]);

  async function fetchTemplate(templateId: number) {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('templates')
        .select('*')
        .eq('id', templateId)
        .single();

      if (error) {
        throw error;
      }

      if (data) {
        setTemplate(data);
      }
    } catch (error) {
      console.error('Error fetching template:', error);
    } finally {
      setLoading(false);
    }
  }

  async function startInspection() {
    if (!template) return;
    
    try {
      const { data, error } = await supabase
        .from('inspections')
        .insert([
          {
            template_id: template.id,
            status: 'in progress',
            metadata: formData
          },
        ])
        .select();

      if (error) {
        throw error;
      }

      if (data && data[0]) {
        router.push(`/inspections/${data[0].id}/edit`);
      }
    } catch (error) {
      console.error('Error creating inspection:', error);
    }
  }

  if (loading) {
    return <div className="container mx-auto px-4 py-8">Loading...</div>;
  }

  if (!template && searchParams.templateId) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
          <p>Template not found. Please select a valid template.</p>
        </div>
        <Link href="/templates" className="text-blue-500 hover:text-blue-700">
          ← Back to Templates
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Start New Inspection</h1>
      
      {!searchParams.templateId ? (
        <div>
          <p className="mb-4">Please select a template to start a new inspection.</p>
          <Link 
            href="/templates" 
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          >
            Select Template
          </Link>
        </div>
      ) : (
        <div className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
          <div className="mb-6">
            <h2 className="text-xl font-semibold mb-2">Template: {template?.title}</h2>
            <p className="text-gray-600">{template?.description}</p>
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">
              Location
            </label>
            <input
              type="text"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter inspection location"
            />
          </div>
          
          <div className="mb-4">
            <label className="block text-gray-700 text-sm font-bold mb-2">
              Inspector Name
            </label>
            <input
              type="text"
              value={formData.inspector}
              onChange={(e) => setFormData({ ...formData, inspector: e.target.value })}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter inspector name"
            />
          </div>
          
          <div className="mb-6">
            <label className="block text-gray-700 text-sm font-bold mb-2">
              Notes
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
              placeholder="Enter any additional notes"
              rows={3}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <button
              onClick={startInspection}
              className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline"
            >
              Start Inspection
            </button>
            <Link
              href="/inspections"
              className="inline-block align-baseline font-bold text-sm text-blue-500 hover:text-blue-800"
            >
              Cancel
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
