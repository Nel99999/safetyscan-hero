'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/app/auth/context/AuthContext';
import ProtectedRoute from '@/app/auth/components/ProtectedRoute';
import Link from 'next/link';

export default function IntegrationsPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [integrations, setIntegrations] = useState([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newIntegration, setNewIntegration] = useState({
    name: '',
    type: 'webhook',
    endpoint: '',
    api_key: '',
    events: ['inspection.created', 'inspection.completed'],
    active: true
  });

  useEffect(() => {
    if (user) {
      fetchIntegrations();
    }
  }, [user]);

  async function fetchIntegrations() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('integrations')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      setIntegrations(data || []);
      
    } catch (error) {
      console.error('Error fetching integrations:', error);
    } finally {
      setLoading(false);
    }
  }

  async function createIntegration() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('integrations')
        .insert({
          user_id: user?.id,
          name: newIntegration.name,
          type: newIntegration.type,
          config: {
            endpoint: newIntegration.endpoint,
            api_key: newIntegration.api_key,
            events: newIntegration.events
          },
          active: newIntegration.active
        })
        .select();
        
      if (error) throw error;
      
      // Reset form and close modal
      setNewIntegration({
        name: '',
        type: 'webhook',
        endpoint: '',
        api_key: '',
        events: ['inspection.created', 'inspection.completed'],
        active: true
      });
      
      setShowCreateModal(false);
      
      // Refresh integrations
      fetchIntegrations();
      
    } catch (error) {
      console.error('Error creating integration:', error);
    } finally {
      setLoading(false);
    }
  }

  async function toggleIntegrationStatus(id, currentStatus) {
    try {
      const { error } = await supabase
        .from('integrations')
        .update({ active: !currentStatus })
        .eq('id', id);
        
      if (error) throw error;
      
      // Refresh integrations
      fetchIntegrations();
      
    } catch (error) {
      console.error('Error updating integration status:', error);
    }
  }

  async function deleteIntegration(id) {
    try {
      const { error } = await supabase
        .from('integrations')
        .delete()
        .eq('id', id);
        
      if (error) throw error;
      
      // Refresh integrations
      fetchIntegrations();
      
    } catch (error) {
      console.error('Error deleting integration:', error);
    }
  }

  function handleInputChange(e) {
    const { name, value, type, checked } = e.target;
    setNewIntegration({
      ...newIntegration,
      [name]: type === 'checkbox' ? checked : value
    });
  }

  function handleEventChange(event) {
    const currentEvents = [...newIntegration.events];
    
    if (currentEvents.includes(event)) {
      // Remove event if already selected
      setNewIntegration({
        ...newIntegration,
        events: currentEvents.filter(e => e !== event)
      });
    } else {
      // Add event if not already selected
      setNewIntegration({
        ...newIntegration,
        events: [...currentEvents, event]
      });
    }
  }

  function getIntegrationTypeIcon(type) {
    switch(type.toLowerCase()) {
      case 'webhook':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        );
      case 'api':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
          </svg>
        );
      case 'email':
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
          </svg>
        );
      default:
        return (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        );
    }
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Integration Capabilities</h1>
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          >
            Create Integration
          </button>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Your Integrations</h2>
          
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : integrations.length > 0 ? (
            <div className="space-y-4">
              {integrations.map((integration) => (
                <div key={integration.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      <div className="mr-3">
                        {getIntegrationTypeIcon(integration.type)}
                      </div>
                      <div>
                        <h3 className="font-semibold">{integration.name}</h3>
                        <p className="text-gray-500 text-sm">
                          {integration.type.charAt(0).toUpperCase() + integration.type.slice(1)} Integration
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        integration.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {integration.active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-gray-500">Endpoint</p>
                      <p className="text-sm text-gray-800 truncate">{integration.config?.endpoint}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-500">Events</p>
                      <div className="flex flex-wrap gap-1">
                        {integration.config?.events?.map((event, index) => (
                          <span key={index} className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded">
                            {event}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-4 flex justify-end space-x-2">
                    <button
                      onClick={() => toggleIntegrationStatus(integration.id, integration.active)}
                      className="text-blue-500 hover:text-blue-700 text-sm"
                    >
                      {integration.active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button
                      onClick={() => deleteIntegration(integration.id)}
                      className="text-red-500 hover:text-red-700 text-sm"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-yellow-700">
                    No integrations found. Create an integration to connect SafetyScan Hero with your other systems.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-500 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              <h2 className="text-xl font-semibold">Webhooks</h2>
            </div>
            <p className="text-gray-600 mb-4">
              Send real-time notifications to your systems when events occur in SafetyScan Hero.
            </p>
            <ul className="space-y-2 mb-4">
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Inspection created/completed</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Critical findings detected</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Template updates</span>
              </li>
            </ul>
            <button
              onClick={() => {
                setNewIntegration({
                  ...newIntegration,
                  type: 'webhook'
                });
                setShowCreateModal(true);
              }}
              className="text-blue-500 hover:text-blue-700 font-medium"
            >
              Set up webhook →
            </button>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-500 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
              </svg>
              <h2 className="text-xl font-semibold">API Access</h2>
            </div>
            <p className="text-gray-600 mb-4">
              Access your SafetyScan Hero data programmatically through our REST API.
            </p>
            <ul className="space-y-2 mb-4">
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Fetch inspection data</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Create and update templates</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Generate reports</span>
              </li>
            </ul>
            <button
              onClick={() => {
                setNewIntegration({
                  ...newIntegration,
                  type: 'api'
                });
                setShowCreateModal(true);
              }}
              className="text-blue-500 hover:text-blue-700 font-medium"
            >
              Set up API access →
            </button>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-500 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              <h2 className="text-xl font-semibold">Email Notifications</h2>
            </div>
            <p className="text-gray-600 mb-4">
              Send automated email notifications to stakeholders based on inspection events.
            </p>
            <ul className="space-y-2 mb-4">
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Inspection completion summaries</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Critical finding alerts</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Scheduled inspection reminders</span>
              </li>
            </ul>
            <button
              onClick={() => {
                setNewIntegration({
                  ...newIntegration,
                  type: 'email'
                });
                setShowCreateModal(true);
              }}
              className="text-blue-500 hover:text-blue-700 font-medium"
            >
              Set up email notifications →
            </button>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">API Documentation</h2>
          <p className="text-gray-600 mb-6">
            Our comprehensive API allows you to integrate SafetyScan Hero with your existing systems.
            Below are some example endpoints and their usage.
          </p>
          
          <div className="space-y-6">
            <div className="border rounded-lg overflow-hidden">
              <div className="bg-gray-100 px-4 py-2 border-b">
                <div className="flex items-center">
                  <span className="bg-green-500 text-white px-2 py-1 rounded text-xs font-bold mr-2">GET</span>
                  <code className="text-sm">/api/v1/inspections</code>
                </div>
              </div>
              <div className="p-4">
                <p className="text-sm text-gray-600 mb-2">Retrieve a list of inspections with optional filtering.</p>
                <pre className="bg-gray-50 p-2 rounded text-xs overflow-x-auto">
                  {`// Example request
fetch('https://api.safetyscanhero.com/v1/inspections?status=completed', {
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY'
  }
})
.then(response => response.json())
.then(data => console.log(data));`}
                </pre>
              </div>
            </div>
            
            <div className="border rounded-lg overflow-hidden">
              <div className="bg-gray-100 px-4 py-2 border-b">
                <div className="flex items-center">
                  <span className="bg-blue-500 text-white px-2 py-1 rounded text-xs font-bold mr-2">POST</span>
                  <code className="text-sm">/api/v1/templates</code>
                </div>
              </div>
              <div className="p-4">
                <p className="text-sm text-gray-600 mb-2">Create a new inspection template.</p>
                <pre className="bg-gray-50 p-2 rounded text-xs overflow-x-auto">
                  {`// Example request
fetch('https://api.safetyscanhero.com/v1/templates', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer YOUR_API_KEY',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    title: 'Fire Safety Inspection',
    description: 'Monthly fire safety inspection template',
    sections: [
      {
        title: 'Fire Extinguishers',
        questions: [
          {
            text: 'Are fire extinguishers properly mounted?',
            type: 'yes_no',
            required: true
          }
        ]
      }
    ]
  })
})
.then(response => response.json())
.then(data => console.log(data));`}
                </pre>
              </div>
            </div>
          </div>
          
          <div className="mt-4">
            <a href="#" className="text-blue-500 hover:text-blue-700 font-medium">
              View full API documentation →
            </a>
          </div>
        </div>
        
        <div className="mt-8">
          <Link href="/" className="text-blue-500 hover:text-blue-700">
            ← Back to Dashboard
          </Link>
        </div>
        
        {/* Create Integration Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h3 className="text-xl font-semibold mb-4">Create Integration</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Integration Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={newIntegration.name}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter integration name"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Integration Type
                  </label>
                  <select
                    name="type"
                    value={newIntegration.type}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    <option value="webhook">Webhook</option>
                    <option value="api">API</option>
                    <option value="email">Email Notification</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    {newIntegration.type === 'email' ? 'Email Address' : 'Endpoint URL'}
                  </label>
                  <input
                    type={newIntegration.type === 'email' ? 'email' : 'text'}
                    name="endpoint"
                    value={newIntegration.endpoint}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder={newIntegration.type === 'email' ? 'Enter email address' : 'Enter endpoint URL'}
                    required
                  />
                </div>
                
                {newIntegration.type !== 'email' && (
                  <div>
                    <label className="block text-gray-700 text-sm font-bold mb-2">
                      API Key (optional)
                    </label>
                    <input
                      type="text"
                      name="api_key"
                      value={newIntegration.api_key}
                      onChange={handleInputChange}
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                      placeholder="Enter API key"
                    />
                  </div>
                )}
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Trigger Events
                  </label>
                  <div className="space-y-2">
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={newIntegration.events.includes('inspection.created')}
                        onChange={() => handleEventChange('inspection.created')}
                        className="mr-2"
                      />
                      <span className="text-gray-700">Inspection Created</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={newIntegration.events.includes('inspection.completed')}
                        onChange={() => handleEventChange('inspection.completed')}
                        className="mr-2"
                      />
                      <span className="text-gray-700">Inspection Completed</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={newIntegration.events.includes('finding.critical')}
                        onChange={() => handleEventChange('finding.critical')}
                        className="mr-2"
                      />
                      <span className="text-gray-700">Critical Finding Detected</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="checkbox"
                        checked={newIntegration.events.includes('template.updated')}
                        onChange={() => handleEventChange('template.updated')}
                        className="mr-2"
                      />
                      <span className="text-gray-700">Template Updated</span>
                    </label>
                  </div>
                </div>
                
                <div>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="active"
                      checked={newIntegration.active}
                      onChange={handleInputChange}
                      className="mr-2"
                    />
                    <span className="text-gray-700">Activate integration immediately</span>
                  </label>
                </div>
              </div>
              
              <div className="flex justify-end mt-6 space-x-2">
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={createIntegration}
                  disabled={!newIntegration.name || !newIntegration.endpoint || newIntegration.events.length === 0}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
                >
                  Create Integration
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}
