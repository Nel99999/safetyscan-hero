'use client';

import { ReactNode } from 'react';
import { useAuth } from '../context/AuthContext';
import { useRouter } from 'next/navigation';

interface ProtectedRouteProps {
  children: ReactNode;
  requiredRole?: string[];
}

export default function ProtectedRoute({ 
  children, 
  requiredRole = ['user', 'admin', 'inspector'] 
}: ProtectedRouteProps) {
  const { user, isLoading } = useAuth();
  const router = useRouter();

  // If authentication is still loading, show loading state
  if (isLoading) {
    return <div className="flex justify-center items-center min-h-screen">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
    </div>;
  }

  // If user is not authenticated, redirect to sign in
  if (!user) {
    router.push('/auth/signin');
    return null;
  }

  // If role-based access control is required and user doesn't have the required role
  if (requiredRole.length > 0 && !requiredRole.includes(user.role)) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
          <p className="font-bold">Access Denied</p>
          <p>You do not have permission to access this page.</p>
        </div>
        <button 
          onClick={() => router.push('/')}
          className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          Return to Home
        </button>
      </div>
    );
  }

  // User is authenticated and has the required role
  return <>{children}</>;
}
