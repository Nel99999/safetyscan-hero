'use client';

import { useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { supabase } from '@/lib/supabase';

export default function AuthCallbackPage() {
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    // Get the auth code from the URL
    const code = searchParams.get('code');
    
    // If there's no code in the URL, redirect to sign in
    if (!code) {
      router.push('/auth/signin');
      return;
    }

    // Exchange the auth code for a session
    async function exchangeCodeForSession() {
      try {
        // Exchange the code for a session
        await supabase.auth.exchangeCodeForSession(code);
        
        // Redirect to home page after successful authentication
        router.push('/');
      } catch (error) {
        console.error('Error exchanging code for session:', error);
        router.push('/auth/signin');
      }
    }

    exchangeCodeForSession();
  }, [router, searchParams]);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md space-y-8 text-center">
        <h2 className="text-2xl font-bold">Completing authentication...</h2>
        <div className="flex justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </div>
    </div>
  );
}
