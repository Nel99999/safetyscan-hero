'use client';

import { useAuth } from '../auth/context/AuthContext';
import AuthForm from '../auth/components/AuthForm';

export default function SignInPage() {
  const { user } = useAuth();

  // If user is already signed in, show a message
  if (user) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-md space-y-8 text-center">
          <h2 className="text-2xl font-bold">You are already signed in</h2>
          <p className="mt-2">You are currently signed in as {user.email}</p>
          <a 
            href="/"
            className="mt-4 inline-block rounded-md bg-blue-600 px-4 py-2 text-white hover:bg-blue-500"
          >
            Go to Home
          </a>
        </div>
      </div>
    );
  }

  return <AuthForm type="signin" />;
}
