'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/app/auth/context/AuthContext';
import ProtectedRoute from '@/app/auth/components/ProtectedRoute';
import Link from 'next/link';

export default function CompliancePage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [requirements, setRequirements] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [inspections, setInspections] = useState([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newRequirement, setNewRequirement] = useState({
    name: '',
    standard: '',
    description: '',
    due_date: '',
    frequency: 'monthly',
    templates: []
  });
  const [complianceStats, setComplianceStats] = useState({
    total: 0,
    compliant: 0,
    nonCompliant: 0,
    upcoming: 0,
    percentage: 0
  });
  const [selectedRequirement, setSelectedRequirement] = useState(null);
  const [requirementDetails, setRequirementDetails] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editRequirement, setEditRequirement] = useState(null);
  const [regulatoryStandards, setRegulatoryStandards] = useState([
    { id: 'osha', name: 'OSHA Standards' },
    { id: 'iso45001', name: 'ISO 45001' },
    { id: 'iso9001', name: 'ISO 9001' },
    { id: 'iso14001', name: 'ISO 14001' },
    { id: 'haccp', name: 'HACCP' },
    { id: 'gdpr', name: 'GDPR' },
    { id: 'hipaa', name: 'HIPAA' },
    { id: 'custom', name: 'Custom Standard' }
  ]);

  useEffect(() => {
    if (user) {
      fetchRequirements();
      fetchTemplates();
      fetchInspections();
    }
  }, [user]);

  useEffect(() => {
    if (requirements.length > 0) {
      calculateComplianceStats();
    }
  }, [requirements, inspections]);

  useEffect(() => {
    if (selectedRequirement) {
      fetchRequirementDetails(selectedRequirement);
    }
  }, [selectedRequirement]);

  async function fetchRequirements() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('compliance_requirements')
        .select(`
          id,
          name,
          standard,
          description,
          due_date,
          frequency,
          created_at,
          updated_at,
          templates,
          status
        `)
        .order('due_date', { ascending: true });
        
      if (error) throw error;
      
      setRequirements(data || []);
      
      // Set the first requirement as selected if available
      if (data && data.length > 0 && !selectedRequirement) {
        setSelectedRequirement(data[0].id);
      }
      
    } catch (error) {
      console.error('Error fetching compliance requirements:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchTemplates() {
    try {
      const { data, error } = await supabase
        .from('templates')
        .select('id, title, category')
        .order('title');
        
      if (error) throw error;
      
      setTemplates(data || []);
      
    } catch (error) {
      console.error('Error fetching templates:', error);
    }
  }

  async function fetchInspections() {
    try {
      const { data, error } = await supabase
        .from('inspections')
        .select(`
          id,
          created_at,
          template_id,
          status,
          findings,
          score
        `)
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      
      setInspections(data || []);
      
    } catch (error) {
      console.error('Error fetching inspections:', error);
    }
  }

  async function fetchRequirementDetails(requirementId) {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('compliance_requirements')
        .select(`
          id,
          name,
          standard,
          description,
          due_date,
          frequency,
          created_at,
          updated_at,
          templates,
          status
        `)
        .eq('id', requirementId)
        .single();
        
      if (error) throw error;
      
      setRequirementDetails(data);
      
      // Prepare related inspections
      if (data && data.templates && data.templates.length > 0) {
        const relatedInspections = inspections.filter(inspection => 
          data.templates.includes(inspection.template_id)
        );
        
        setRequirementDetails({
          ...data,
          relatedInspections
        });
      }
      
    } catch (error) {
      console.error('Error fetching requirement details:', error);
    } finally {
      setLoading(false);
    }
  }

  async function createRequirement() {
    try {
      setLoading(true);
      
      // Convert template IDs to integers
      const templateIds = newRequirement.templates.map(id => parseInt(id));
      
      const { data, error } = await supabase
        .from('compliance_requirements')
        .insert({
          name: newRequirement.name,
          standard: newRequirement.standard,
          description: newRequirement.description,
          due_date: newRequirement.due_date,
          frequency: newRequirement.frequency,
          templates: templateIds,
          status: 'pending' // Initial status
        })
        .select();
        
      if (error) throw error;
      
      // Reset form and close modal
      setNewRequirement({
        name: '',
        standard: '',
        description: '',
        due_date: '',
        frequency: 'monthly',
        templates: []
      });
      
      setShowCreateModal(false);
      
      // Refresh requirements
      fetchRequirements();
      
    } catch (error) {
      console.error('Error creating compliance requirement:', error);
    } finally {
      setLoading(false);
    }
  }

  async function updateRequirement() {
    if (!editRequirement) return;
    
    try {
      setLoading(true);
      
      // Convert template IDs to integers
      const templateIds = editRequirement.templates.map(id => 
        typeof id === 'string' ? parseInt(id) : id
      );
      
      const { error } = await supabase
        .from('compliance_requirements')
        .update({
          name: editRequirement.name,
          standard: editRequirement.standard,
          description: editRequirement.description,
          due_date: editRequirement.due_date,
          frequency: editRequirement.frequency,
          templates: templateIds,
          updated_at: new Date().toISOString()
        })
        .eq('id', editRequirement.id);
        
      if (error) throw error;
      
      // Close modal
      setShowEditModal(false);
      setEditRequirement(null);
      
      // Refresh requirements and details
      fetchRequirements();
      if (selectedRequirement) {
        fetchRequirementDetails(selectedRequirement);
      }
      
    } catch (error) {
      console.error('Error updating compliance requirement:', error);
    } finally {
      setLoading(false);
    }
  }

  async function updateRequirementStatus(requirementId, newStatus) {
    try {
      const { error } = await supabase
        .from('compliance_requirements')
        .update({
          status: newStatus,
          updated_at: new Date().toISOString()
        })
        .eq('id', requirementId);
        
      if (error) throw error;
      
      // Refresh requirements and details
      fetchRequirements();
      if (selectedRequirement === requirementId) {
        fetchRequirementDetails(requirementId);
      }
      
    } catch (error) {
      console.error('Error updating requirement status:', error);
    }
  }

  async function deleteRequirement(requirementId) {
    if (!confirm('Are you sure you want to delete this requirement? This action cannot be undone.')) {
      return;
    }
    
    try {
      const { error } = await supabase
        .from('compliance_requirements')
        .delete()
        .eq('id', requirementId);
        
      if (error) throw error;
      
      // Reset selected requirement if it was deleted
      if (selectedRequirement === requirementId) {
        setSelectedRequirement(null);
        setRequirementDetails(null);
      }
      
      // Refresh requirements
      fetchRequirements();
      
    } catch (error) {
      console.error('Error deleting compliance requirement:', error);
    }
  }

  function calculateComplianceStats() {
    const total = requirements.length;
    let compliant = 0;
    let nonCompliant = 0;
    let upcoming = 0;
    
    requirements.forEach(req => {
      // Check if requirement has related templates with completed inspections
      const hasCompletedInspections = req.templates && req.templates.some(templateId => {
        return inspections.some(insp => 
          insp.template_id === templateId && 
          insp.status === 'completed' &&
          new Date(insp.created_at) <= new Date(req.due_date)
        );
      });
      
      // Check if due date is in the future
      const isDueDateFuture = new Date(req.due_date) > new Date();
      
      if (hasCompletedInspections || req.status === 'compliant') {
        compliant++;
      } else if (!isDueDateFuture || req.status === 'non_compliant') {
        nonCompliant++;
      } else {
        upcoming++;
      }
    });
    
    const percentage = total > 0 ? Math.round((compliant / total) * 100) : 0;
    
    setComplianceStats({
      total,
      compliant,
      nonCompliant,
      upcoming,
      percentage
    });
  }

  function handleTemplateToggle(templateId) {
    const currentTemplates = [...newRequirement.templates];
    
    if (currentTemplates.includes(templateId)) {
      // Remove template if already selected
      setNewRequirement({
        ...newRequirement,
        templates: currentTemplates.filter(id => id !== templateId)
      });
    } else {
      // Add template if not already selected
      setNewRequirement({
        ...newRequirement,
        templates: [...currentTemplates, templateId]
      });
    }
  }

  function handleEditTemplateToggle(templateId) {
    if (!editRequirement) return;
    
    const currentTemplates = [...editRequirement.templates];
    
    if (currentTemplates.includes(templateId)) {
      // Remove template if already selected
      setEditRequirement({
        ...editRequirement,
        templates: currentTemplates.filter(id => id !== templateId)
      });
    } else {
      // Add template if not already selected
      setEditRequirement({
        ...editRequirement,
        templates: [...currentTemplates, templateId]
      });
    }
  }

  function handleInputChange(e, formSetter, formState) {
    const { name, value } = e.target;
    formSetter({
      ...formState,
      [name]: value
    });
  }

  function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString();
  }

  function getStatusColor(status) {
    switch(status) {
      case 'compliant':
        return 'bg-green-100 text-green-800';
      case 'non_compliant':
        return 'bg-red-100 text-red-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  function getStatusLabel(status) {
    switch(status) {
      case 'compliant':
        return 'Compliant';
      case 'non_compliant':
        return 'Non-Compliant';
      case 'pending':
        return 'Pending';
      default:
        return status;
    }
  }

  function getDueDateStatus(dueDate) {
    const today = new Date();
    const due = new Date(dueDate);
    
    const diffTime = due - today;
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) {
      return { label: 'Overdue', color: 'text-red-600' };
    } else if (diffDays <= 7) {
      return { label: `Due in ${diffDays} days`, color: 'text-orange-600' };
    } else if (diffDays <= 30) {
      return { label: `Due in ${diffDays} days`, color: 'text-yellow-600' };
    } else {
      return { label: `Due in ${diffDays} days`, color: 'text-green-600' };
    }
  }

  function getFrequencyLabel(frequency) {
    switch(frequency) {
      case 'daily':
        return 'Daily';
      case 'weekly':
        return 'Weekly';
      case 'monthly':
        return 'Monthly';
      case 'quarterly':
        return 'Quarterly';
      case 'biannually':
        return 'Bi-annually';
      case 'annually':
        return 'Annually';
      default:
        return frequency;
    }
  }

  function openEditModal(requirement) {
    setEditRequirement({
      ...requirement,
      templates: requirement.templates || []
    });
    setShowEditModal(true);
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Compliance Tracking</h1>
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          >
            Add Requirement
          </button>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-blue-600 mb-2">{complianceStats.percentage}%</div>
            <div className="text-gray-500">Overall Compliance</div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-green-600 mb-2">{complianceStats.compliant}</div>
            <div className="text-gray-500">Compliant Requirements</div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-red-600 mb-2">{complianceStats.nonCompliant}</div>
            <div className="text-gray-500">Non-Compliant Requirements</div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-yellow-600 mb-2">{complianceStats.upcoming}</div>
            <div className="text-gray-500">Upcoming Requirements</div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4">Requirements</h2>
              
              {loading && requirements.length === 0 ? (
                <div className="flex justify-center items-center h-64">
                  <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
                </div>
              ) : requirements.length > 0 ? (
                <div className="space-y-3">
                  {requirements.map((req) => (
                    <div 
                      key={req.id} 
                      className={`border rounded-lg p-3 cursor-pointer hover:bg-gray-50 ${
                        selectedRequirement === req.id ? 'border-blue-500 bg-blue-50' : ''
                      }`}
                      onClick={() => setSelectedRequirement(req.id)}
                    >
                      <div className="flex justify-between items-start">
                        <h3 className="font-medium">{req.name}</h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(req.status)}`}>
                          {getStatusLabel(req.status)}
                        </span>
                      </div>
                      <p className="text-gray-500 text-sm">{req.standard}</p>
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-xs text-gray-500">
                          {getFrequencyLabel(req.frequency)}
                        </span>
                        <span className={`text-xs ${getDueDateStatus(req.due_date).color}`}>
                          {getDueDateStatus(req.due_date).label}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                  <div className="flex">
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">
                        No compliance requirements found. Add a requirement to get started.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="lg:col-span-2">
            {requirementDetails ? (
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-2xl font-semibold">{requirementDetails.name}</h2>
                    <p className="text-gray-500">{requirementDetails.standard}</p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => openEditModal(requirementDetails)}
                      className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-3 rounded text-sm"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => deleteRequirement(requirementDetails.id)}
                      className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded text-sm"
                    >
                      Delete
                    </button>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Description</h3>
                    <p className="mt-1">{requirementDetails.description}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Status</h3>
                    <div className="mt-1 flex items-center space-x-2">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(requirementDetails.status)}`}>
                        {getStatusLabel(requirementDetails.status)}
                      </span>
                      
                      <div className="flex space-x-1">
                        <button
                          onClick={() => updateRequirementStatus(requirementDetails.id, 'compliant')}
                          className="bg-green-100 hover:bg-green-200 text-green-800 text-xs py-1 px-2 rounded"
                        >
                          Mark Compliant
                        </button>
                        <button
                          onClick={() => updateRequirementStatus(requirementDetails.id, 'non_compliant')}
                          className="bg-red-100 hover:bg-red-200 text-red-800 text-xs py-1 px-2 rounded"
                        >
                          Mark Non-Compliant
                        </button>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Due Date</h3>
                    <p className="mt-1">{formatDate(requirementDetails.due_date)}</p>
                    <p className={`text-xs ${getDueDateStatus(requirementDetails.due_date).color}`}>
                      {getDueDateStatus(requirementDetails.due_date).label}
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Frequency</h3>
                    <p className="mt-1">{getFrequencyLabel(requirementDetails.frequency)}</p>
                  </div>
                </div>
                
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Associated Templates</h3>
                  {requirementDetails.templates && requirementDetails.templates.length > 0 ? (
                    <div className="space-y-2">
                      {requirementDetails.templates.map(templateId => {
                        const template = templates.find(t => t.id === templateId);
                        return template ? (
                          <div key={template.id} className="bg-gray-100 rounded p-2">
                            <p className="font-medium">{template.title}</p>
                            <p className="text-xs text-gray-500">{template.category}</p>
                          </div>
                        ) : null;
                      })}
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm">No templates associated with this requirement.</p>
                  )}
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-2">Related Inspections</h3>
                  {requirementDetails.relatedInspections && requirementDetails.relatedInspections.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Date
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Template
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Status
                            </th>
                            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                              Score
                            </th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {requirementDetails.relatedInspections.map((inspection) => {
                            const template = templates.find(t => t.id === inspection.template_id);
                            return (
                              <tr key={inspection.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {formatDate(inspection.created_at)}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                  {template ? template.title : 'Unknown Template'}
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap">
                                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                    {inspection.status}
                                  </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                  {inspection.score ? `${inspection.score}%` : 'N/A'}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm">No inspections found for this requirement.</p>
                  )}
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow p-6 flex items-center justify-center h-64">
                <p className="text-gray-500">
                  {requirements.length > 0 
                    ? 'Select a requirement to view details' 
                    : 'Add a compliance requirement to get started'}
                </p>
              </div>
            )}
          </div>
        </div>
        
        <div className="mt-8">
          <Link href="/" className="text-blue-500 hover:text-blue-700">
            ← Back to Dashboard
          </Link>
        </div>
        
        {/* Create Requirement Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-screen overflow-y-auto">
              <h3 className="text-xl font-semibold mb-4">Add Compliance Requirement</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Requirement Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={newRequirement.name}
                    onChange={(e) => handleInputChange(e, setNewRequirement, newRequirement)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter requirement name"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Regulatory Standard
                  </label>
                  <select
                    name="standard"
                    value={newRequirement.standard}
                    onChange={(e) => handleInputChange(e, setNewRequirement, newRequirement)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    required
                  >
                    <option value="">Select a standard</option>
                    {regulatoryStandards.map(standard => (
                      <option key={standard.id} value={standard.name}>
                        {standard.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={newRequirement.description}
                    onChange={(e) => handleInputChange(e, setNewRequirement, newRequirement)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter requirement description"
                    rows={3}
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Due Date
                  </label>
                  <input
                    type="date"
                    name="due_date"
                    value={newRequirement.due_date}
                    onChange={(e) => handleInputChange(e, setNewRequirement, newRequirement)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Frequency
                  </label>
                  <select
                    name="frequency"
                    value={newRequirement.frequency}
                    onChange={(e) => handleInputChange(e, setNewRequirement, newRequirement)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="quarterly">Quarterly</option>
                    <option value="biannually">Bi-annually</option>
                    <option value="annually">Annually</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Associated Templates
                  </label>
                  <div className="max-h-40 overflow-y-auto border rounded p-2">
                    {templates.map(template => (
                      <label key={template.id} className="flex items-center py-1">
                        <input
                          type="checkbox"
                          checked={newRequirement.templates.includes(template.id)}
                          onChange={() => handleTemplateToggle(template.id)}
                          className="mr-2"
                        />
                        <span>{template.title}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end mt-6 space-x-2">
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={createRequirement}
                  disabled={!newRequirement.name || !newRequirement.standard || !newRequirement.due_date}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
                >
                  Create Requirement
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Edit Requirement Modal */}
        {showEditModal && editRequirement && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-screen overflow-y-auto">
              <h3 className="text-xl font-semibold mb-4">Edit Compliance Requirement</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Requirement Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={editRequirement.name}
                    onChange={(e) => handleInputChange(e, setEditRequirement, editRequirement)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter requirement name"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Regulatory Standard
                  </label>
                  <select
                    name="standard"
                    value={editRequirement.standard}
                    onChange={(e) => handleInputChange(e, setEditRequirement, editRequirement)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    required
                  >
                    <option value="">Select a standard</option>
                    {regulatoryStandards.map(standard => (
                      <option key={standard.id} value={standard.name}>
                        {standard.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={editRequirement.description}
                    onChange={(e) => handleInputChange(e, setEditRequirement, editRequirement)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter requirement description"
                    rows={3}
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Due Date
                  </label>
                  <input
                    type="date"
                    name="due_date"
                    value={editRequirement.due_date ? editRequirement.due_date.split('T')[0] : ''}
                    onChange={(e) => handleInputChange(e, setEditRequirement, editRequirement)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Frequency
                  </label>
                  <select
                    name="frequency"
                    value={editRequirement.frequency}
                    onChange={(e) => handleInputChange(e, setEditRequirement, editRequirement)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="quarterly">Quarterly</option>
                    <option value="biannually">Bi-annually</option>
                    <option value="annually">Annually</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Associated Templates
                  </label>
                  <div className="max-h-40 overflow-y-auto border rounded p-2">
                    {templates.map(template => (
                      <label key={template.id} className="flex items-center py-1">
                        <input
                          type="checkbox"
                          checked={editRequirement.templates.includes(template.id)}
                          onChange={() => handleEditTemplateToggle(template.id)}
                          className="mr-2"
                        />
                        <span>{template.title}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="flex justify-end mt-6 space-x-2">
                <button
                  onClick={() => {
                    setShowEditModal(false);
                    setEditRequirement(null);
                  }}
                  className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={updateRequirement}
                  disabled={!editRequirement.name || !editRequirement.standard || !editRequirement.due_date}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
                >
                  Update Requirement
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}
