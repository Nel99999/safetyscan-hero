'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/app/auth/context/AuthContext';
import ProtectedRoute from '@/app/auth/components/ProtectedRoute';
import Link from 'next/link';

export default function MobileIntegrationPage() {
  const { user } = useAuth();
  const [qrCode, setQrCode] = useState('');
  const [loading, setLoading] = useState(true);
  const [deviceCount, setDeviceCount] = useState(0);
  const [mobileSettings, setMobileSettings] = useState({
    enableOfflineMode: true,
    enablePhotoCompression: true,
    enableLocationTracking: true,
    syncFrequency: 'auto'
  });

  useEffect(() => {
    if (user) {
      fetchMobileData();
      generateQRCode();
    }
  }, [user]);

  async function fetchMobileData() {
    try {
      setLoading(true);
      
      // Fetch mobile devices count
      const { data, error } = await supabase
        .from('user_devices')
        .select('*')
        .eq('user_id', user?.id);
        
      if (error) throw error;
      
      setDeviceCount(data?.length || 0);
      
      // Fetch mobile settings
      const { data: settingsData, error: settingsError } = await supabase
        .from('user_settings')
        .select('mobile_settings')
        .eq('user_id', user?.id)
        .single();
        
      if (!settingsError && settingsData?.mobile_settings) {
        setMobileSettings(settingsData.mobile_settings);
      }
      
    } catch (error) {
      console.error('Error fetching mobile data:', error);
    } finally {
      setLoading(false);
    }
  }

  async function generateQRCode() {
    try {
      // In a real implementation, this would generate a QR code with authentication tokens
      // For this demo, we'll create a placeholder QR code URL
      const qrData = {
        appId: 'safetyscan-hero',
        userId: user?.id,
        timestamp: new Date().getTime(),
        apiUrl: window.location.origin
      };
      
      const qrString = JSON.stringify(qrData);
      const encodedData = encodeURIComponent(qrString);
      
      // Using a public QR code generation service
      setQrCode(`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodedData}`);
      
    } catch (error) {
      console.error('Error generating QR code:', error);
    }
  }

  async function updateMobileSettings(settings) {
    try {
      setLoading(true);
      
      const { error } = await supabase
        .from('user_settings')
        .upsert({
          user_id: user?.id,
          mobile_settings: settings
        });
        
      if (error) throw error;
      
      setMobileSettings(settings);
      
    } catch (error) {
      console.error('Error updating mobile settings:', error);
    } finally {
      setLoading(false);
    }
  }

  function handleSettingChange(setting, value) {
    const updatedSettings = {
      ...mobileSettings,
      [setting]: value
    };
    
    updateMobileSettings(updatedSettings);
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Mobile Integration</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="md:col-span-2">
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4">Mobile App Access</h2>
              <p className="mb-4">
                Access SafetyScan Hero on your mobile device for on-the-go inspections, even when offline.
                Our mobile app provides all the functionality of the web application with additional
                features like camera integration, barcode scanning, and GPS location tracking.
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-2">Download the App</h3>
                  <p className="text-gray-600 mb-3">
                    Download the SafetyScan Hero mobile app from your device's app store:
                  </p>
                  <div className="flex space-x-4 mb-4">
                    <a href="#" className="inline-block bg-black text-white px-4 py-2 rounded">
                      <div className="flex items-center">
                        <span className="mr-2">
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.19 2.3-.89 3.55-.84 1.5.09 2.64.64 3.36 1.64-3.09 1.72-2.6 5.88.42 6.92-.68 1.93-1.63 3.81-2.41 4.45zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.32 2.32-1.66 4.22-3.74 4.25z"/>
                          </svg>
                        </span>
                        <div className="text-left">
                          <div className="text-xs">Download on the</div>
                          <div className="text-sm font-semibold">App Store</div>
                        </div>
                      </div>
                    </a>
                    <a href="#" className="inline-block bg-black text-white px-4 py-2 rounded">
                      <div className="flex items-center">
                        <span className="mr-2">
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M3.609 1.814L13.792 12 3.609 22.186c-.181.181-.29.423-.29.679v.135c0 .135.028.27.079.396.232.569.933.776 1.42.396L15.753 12 4.818 1.403c-.487-.38-1.188-.173-1.42.396-.051.126-.079.261-.079.396v.135c0 .256.109.498.29.679"/>
                          </svg>
                        </span>
                        <div className="text-left">
                          <div className="text-xs">GET IT ON</div>
                          <div className="text-sm font-semibold">Google Play</div>
                        </div>
                      </div>
                    </a>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-semibold mb-2">Connect Your Account</h3>
                  <p className="text-gray-600 mb-3">
                    Scan this QR code with the SafetyScan Hero mobile app to connect your account:
                  </p>
                  {qrCode && (
                    <div className="flex justify-center p-4 bg-gray-100 rounded-lg">
                      <img src={qrCode} alt="QR Code" className="w-32 h-32" />
                    </div>
                  )}
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4">Mobile Features</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="border rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-blue-100 p-2 rounded-full mr-3">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
                      </svg>
                    </div>
                    <h3 className="font-semibold">Offline Mode</h3>
                  </div>
                  <p className="text-gray-600">
                    Complete inspections without internet connection. All data will be synchronized when you're back online.
                  </p>
                </div>
                
                <div className="border rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-green-100 p-2 rounded-full mr-3">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </div>
                    <h3 className="font-semibold">Camera Integration</h3>
                  </div>
                  <p className="text-gray-600">
                    Take photos directly within inspections to document findings and evidence.
                  </p>
                </div>
                
                <div className="border rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-purple-100 p-2 rounded-full mr-3">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                      </svg>
                    </div>
                    <h3 className="font-semibold">Barcode Scanning</h3>
                  </div>
                  <p className="text-gray-600">
                    Scan equipment barcodes and QR codes to quickly identify and record assets during inspections.
                  </p>
                </div>
                
                <div className="border rounded-lg p-4">
                  <div className="flex items-center mb-3">
                    <div className="bg-red-100 p-2 rounded-full mr-3">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </div>
                    <h3 className="font-semibold">GPS Location</h3>
                  </div>
                  <p className="text-gray-600">
                    Automatically record location data with each inspection for accurate tracking and verification.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <div className="bg-white rounded-lg shadow p-6 mb-6">
              <h2 className="text-xl font-semibold mb-4">Mobile Settings</h2>
              
              <div className="space-y-4">
                <div>
                  <label className="flex items-center cursor-pointer">
                    <div className="relative">
                      <input 
                        type="checkbox" 
                        className="sr-only" 
                        checked={mobileSettings.enableOfflineMode}
                        onChange={(e) => handleSettingChange('enableOfflineMode', e.target.checked)}
                      />
                      <div className={`block w-10 h-6 rounded-full ${mobileSettings.enableOfflineMode ? 'bg-blue-400' : 'bg-gray-300'}`}></div>
                      <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition ${mobileSettings.enableOfflineMode ? 'transform translate-x-4' : ''}`}></div>
                    </div>
                    <div className="ml-3 text-gray-700 font-medium">
                      Enable Offline Mode
                    </div>
                  </label>
                  <p className="text-gray-500 text-sm mt-1 ml-14">
                    Allow app to work without internet connection
                  </p>
                </div>
                
                <div>
                  <label className="flex items-center cursor-pointer">
                    <div className="relative">
                      <input 
                        type="checkbox" 
                        className="sr-only" 
                        checked={mobileSettings.enablePhotoCompression}
                        onChange={(e) => handleSettingChange('enablePhotoCompression', e.target.checked)}
                      />
                      <div className={`block w-10 h-6 rounded-full ${mobileSettings.enablePhotoCompression ? 'bg-blue-400' : 'bg-gray-300'}`}></div>
                      <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition ${mobileSettings.enablePhotoCompression ? 'transform translate-x-4' : ''}`}></div>
                    </div>
                    <div className="ml-3 text-gray-700 font-medium">
                      Photo Compression
                    </div>
                  </label>
                  <p className="text-gray-500 text-sm mt-1 ml-14">
                    Compress photos to save storage and bandwidth
                  </p>
                </div>
                
                <div>
                  <label className="flex items-center cursor-pointer">
                    <div className="relative">
                      <input 
                        type="checkbox" 
                        className="sr-only" 
                        checked={mobileSettings.enableLocationTracking}
                        onChange={(e) => handleSettingChange('enableLocationTracking', e.target.checked)}
                      />
                      <div className={`block w-10 h-6 rounded-full ${mobileSettings.enableLocationTracking ? 'bg-blue-400' : 'bg-gray-300'}`}></div>
                      <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition ${mobileSettings.enableLocationTracking ? 'transform translate-x-4' : ''}`}></div>
                    </div>
                    <div className="ml-3 text-gray-700 font-medium">
                      Location Tracking
                    </div>
                  </label>
                  <p className="text-gray-500 text-sm mt-1 ml-14">
                    Record GPS location with inspections
                  </p>
                </div>
                
                <div>
                  <label className="block text-gray-700 font-medium mb-2">
                    Sync Frequency
                  </label>
                  <select 
                    className="block w-full bg-gray-50 border border-gray-300 rounded-md py-2 px-3"
                    value={mobileSettings.syncFrequency}
                    onChange={(e) => handleSettingChange('syncFrequency', e.target.value)}
                  >
                    <option value="auto">Automatic (when online)</option>
                    <option value="manual">Manual Only</option>
                    <option value="wifi">Wi-Fi Only</option>
                    <option value="daily">Once Daily</option>
                  </select>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-xl font-semibold mb-4">Connected Devices</h2>
              
              {deviceCount > 0 ? (
                <div className="space-y-3">
                  <p className="text-gray-600">
                    You have {deviceCount} device(s) connected to your account.
                  </p>
                  <button className="text-blue-500 hover:text-blue-700">
                    Manage Devices
                  </button>
                </div>
              ) : (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                  <div className="flex">
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">
                        No devices connected. Download the mobile app and scan the QR code to connect.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <Link href="/" className="text-blue-500 hover:text-blue-700">
            ← Back to Dashboard
          </Link>
        </div>
      </div>
    </ProtectedRoute>
  );
}
