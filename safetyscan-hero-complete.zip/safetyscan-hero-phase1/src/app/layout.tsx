'use client';

import { Inter } from 'next/font/google';
import './globals.css';
import { AuthProvider } from './auth/context/AuthContext';
import ProtectedRoute from './auth/components/ProtectedRoute';
import { useAuth } from './auth/context/AuthContext';
import Link from 'next/link';

const inter = Inter({ subsets: ['latin'] });

// Metadata needs to be in a separate metadata.ts file when using 'use client'
// or removed from a client component

function Navigation() {
  const { user, signOut } = useAuth();

  return (
    <header className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-xl font-bold">SafetyScan Hero</h1>
        <nav>
          <ul className="flex space-x-4 items-center">
            <li><Link href="/" className="hover:underline">Home</Link></li>
            <li><Link href="/templates" className="hover:underline">Templates</Link></li>
            <li><Link href="/inspections" className="hover:underline">Inspections</Link></li>
            {user ? (
              <li>
                <button 
                  onClick={() => signOut()}
                  className="bg-white text-blue-600 px-3 py-1 rounded hover:bg-gray-100"
                >
                  Sign Out
                </button>
              </li>
            ) : (
              <li>
                <Link 
                  href="/auth/signin"
                  className="bg-white text-blue-600 px-3 py-1 rounded hover:bg-gray-100"
                >
                  Sign In
                </Link>
              </li>
            )}
          </ul>
        </nav>
      </div>
    </header>
  );
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <title>SafetyScan Hero - iAuditor Clone</title>
        <meta name="description" content="Safety inspections and audits with Supabase integration" />
      </head>
      <body className={inter.className}>
        <AuthProvider>
          <ProtectedRoute>
            <Navigation />
            {children}
          </ProtectedRoute>
        </AuthProvider>
      </body>
    </html>
  );
}
