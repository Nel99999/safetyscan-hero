'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/app/auth/context/AuthContext';
import ProtectedRoute from '@/app/auth/components/ProtectedRoute';
import Link from 'next/link';

export default function SchedulingPage() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [schedules, setSchedules] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newSchedule, setNewSchedule] = useState({
    template_id: '',
    location: '',
    inspector: '',
    frequency: 'weekly',
    day_of_week: 'monday',
    start_date: '',
    notifications: true
  });

  useEffect(() => {
    if (user) {
      fetchSchedules();
      fetchTemplates();
    }
  }, [user]);

  async function fetchSchedules() {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('inspection_schedules')
        .select(`
          id,
          created_at,
          template_id,
          location,
          inspector,
          frequency,
          day_of_week,
          start_date,
          next_inspection_date,
          notifications,
          status,
          template:template_id (title)
        `)
        .eq('user_id', user?.id)
        .order('next_inspection_date', { ascending: true });
        
      if (error) throw error;
      
      setSchedules(data || []);
      
    } catch (error) {
      console.error('Error fetching schedules:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchTemplates() {
    try {
      const { data, error } = await supabase
        .from('templates')
        .select('id, title')
        .order('title');
        
      if (error) throw error;
      
      setTemplates(data || []);
      
    } catch (error) {
      console.error('Error fetching templates:', error);
    }
  }

  async function createSchedule() {
    try {
      setLoading(true);
      
      // Calculate next inspection date
      const startDate = new Date(newSchedule.start_date);
      const nextDate = calculateNextInspectionDate(
        startDate,
        newSchedule.frequency,
        newSchedule.day_of_week
      );
      
      const { data, error } = await supabase
        .from('inspection_schedules')
        .insert({
          user_id: user?.id,
          template_id: parseInt(newSchedule.template_id),
          location: newSchedule.location,
          inspector: newSchedule.inspector,
          frequency: newSchedule.frequency,
          day_of_week: newSchedule.day_of_week,
          start_date: newSchedule.start_date,
          next_inspection_date: nextDate.toISOString(),
          notifications: newSchedule.notifications,
          status: 'active'
        })
        .select();
        
      if (error) throw error;
      
      // Reset form and close modal
      setNewSchedule({
        template_id: '',
        location: '',
        inspector: '',
        frequency: 'weekly',
        day_of_week: 'monday',
        start_date: '',
        notifications: true
      });
      
      setShowCreateModal(false);
      
      // Refresh schedules
      fetchSchedules();
      
    } catch (error) {
      console.error('Error creating schedule:', error);
    } finally {
      setLoading(false);
    }
  }

  async function toggleScheduleStatus(id, currentStatus) {
    try {
      const newStatus = currentStatus === 'active' ? 'paused' : 'active';
      
      const { error } = await supabase
        .from('inspection_schedules')
        .update({ status: newStatus })
        .eq('id', id);
        
      if (error) throw error;
      
      // Refresh schedules
      fetchSchedules();
      
    } catch (error) {
      console.error('Error updating schedule status:', error);
    }
  }

  async function deleteSchedule(id) {
    try {
      const { error } = await supabase
        .from('inspection_schedules')
        .delete()
        .eq('id', id);
        
      if (error) throw error;
      
      // Refresh schedules
      fetchSchedules();
      
    } catch (error) {
      console.error('Error deleting schedule:', error);
    }
  }

  function calculateNextInspectionDate(startDate, frequency, dayOfWeek) {
    const date = new Date(startDate);
    
    switch(frequency) {
      case 'daily':
        // Next day
        date.setDate(date.getDate() + 1);
        break;
        
      case 'weekly':
        // Next occurrence of the specified day of week
        const days = {
          'sunday': 0,
          'monday': 1,
          'tuesday': 2,
          'wednesday': 3,
          'thursday': 4,
          'friday': 5,
          'saturday': 6
        };
        
        const targetDay = days[dayOfWeek.toLowerCase()];
        const currentDay = date.getDay();
        const daysToAdd = (targetDay + 7 - currentDay) % 7;
        
        date.setDate(date.getDate() + (daysToAdd === 0 ? 7 : daysToAdd));
        break;
        
      case 'biweekly':
        // Two weeks from start date
        date.setDate(date.getDate() + 14);
        break;
        
      case 'monthly':
        // Next month, same day
        date.setMonth(date.getMonth() + 1);
        break;
        
      case 'quarterly':
        // Three months from start date
        date.setMonth(date.getMonth() + 3);
        break;
        
      default:
        // Default to weekly
        date.setDate(date.getDate() + 7);
    }
    
    return date;
  }

  function formatFrequency(frequency, dayOfWeek) {
    switch(frequency) {
      case 'daily':
        return 'Daily';
      case 'weekly':
        return `Weekly on ${dayOfWeek.charAt(0).toUpperCase() + dayOfWeek.slice(1)}s`;
      case 'biweekly':
        return 'Every two weeks';
      case 'monthly':
        return 'Monthly';
      case 'quarterly':
        return 'Quarterly';
      default:
        return frequency;
    }
  }

  function getStatusColor(status) {
    switch(status.toLowerCase()) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'paused':
        return 'bg-yellow-100 text-yellow-800';
      case 'completed':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  }

  function handleInputChange(e) {
    const { name, value, type, checked } = e.target;
    setNewSchedule({
      ...newSchedule,
      [name]: type === 'checkbox' ? checked : value
    });
  }

  return (
    <ProtectedRoute>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Automated Scheduling</h1>
          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
          >
            Create Schedule
          </button>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Inspection Schedules</h2>
          
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : schedules.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Template
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Location
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Frequency
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Next Inspection
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {schedules.map((schedule) => (
                    <tr key={schedule.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {schedule.template?.title || 'Unknown Template'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {schedule.location}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatFrequency(schedule.frequency, schedule.day_of_week)}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        {new Date(schedule.next_inspection_date).toLocaleDateString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(schedule.status)}`}>
                          {schedule.status.charAt(0).toUpperCase() + schedule.status.slice(1)}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex space-x-2">
                          <button
                            onClick={() => toggleScheduleStatus(schedule.id, schedule.status)}
                            className="text-blue-500 hover:text-blue-700"
                          >
                            {schedule.status === 'active' ? 'Pause' : 'Activate'}
                          </button>
                          <button
                            onClick={() => deleteSchedule(schedule.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
              <div className="flex">
                <div className="ml-3">
                  <p className="text-sm text-yellow-700">
                    No schedules found. Create a schedule to automate your inspection process.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">How It Works</h2>
            <div className="space-y-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-8 w-8 rounded-full bg-blue-100 text-blue-600">
                    1
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium">Create a Schedule</h3>
                  <p className="text-gray-500">
                    Select a template, location, and frequency for your inspections.
                  </p>
                </div>
              </div>
              
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-8 w-8 rounded-full bg-blue-100 text-blue-600">
                    2
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium">Automatic Notifications</h3>
                  <p className="text-gray-500">
                    Receive email reminders when inspections are due.
                  </p>
                </div>
              </div>
              
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-8 w-8 rounded-full bg-blue-100 text-blue-600">
                    3
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium">Complete Inspections</h3>
                  <p className="text-gray-500">
                    Perform inspections on schedule to maintain safety compliance.
                  </p>
                </div>
              </div>
              
              <div className="flex">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-8 w-8 rounded-full bg-blue-100 text-blue-600">
                    4
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium">Track Compliance</h3>
                  <p className="text-gray-500">
                    Monitor inspection completion rates and maintain regulatory compliance.
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-semibold mb-4">Benefits of Scheduling</h2>
            <ul className="space-y-2">
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Never miss important safety inspections</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Maintain consistent inspection frequency</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Reduce administrative overhead</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Improve safety compliance</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Demonstrate due diligence for regulatory requirements</span>
              </li>
              <li className="flex items-start">
                <svg className="h-5 w-5 text-green-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <span>Track inspection history and trends over time</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8">
          <Link href="/" className="text-blue-500 hover:text-blue-700">
            ← Back to Dashboard
          </Link>
        </div>
        
        {/* Create Schedule Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg p-6 w-full max-w-md">
              <h3 className="text-xl font-semibold mb-4">Create Inspection Schedule</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Template
                  </label>
                  <select
                    name="template_id"
                    value={newSchedule.template_id}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    required
                  >
                    <option value="">Select a template</option>
                    {templates.map(template => (
                      <option key={template.id} value={template.id}>
                        {template.title}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Location
                  </label>
                  <input
                    type="text"
                    name="location"
                    value={newSchedule.location}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter location"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Inspector
                  </label>
                  <input
                    type="text"
                    name="inspector"
                    value={newSchedule.inspector}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="Enter inspector name"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Frequency
                  </label>
                  <select
                    name="frequency"
                    value={newSchedule.frequency}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                  >
                    <option value="daily">Daily</option>
                    <option value="weekly">Weekly</option>
                    <option value="biweekly">Bi-weekly</option>
                    <option value="monthly">Monthly</option>
                    <option value="quarterly">Quarterly</option>
                  </select>
                </div>
                
                {newSchedule.frequency === 'weekly' && (
                  <div>
                    <label className="block text-gray-700 text-sm font-bold mb-2">
                      Day of Week
                    </label>
                    <select
                      name="day_of_week"
                      value={newSchedule.day_of_week}
                      onChange={handleInputChange}
                      className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    >
                      <option value="monday">Monday</option>
                      <option value="tuesday">Tuesday</option>
                      <option value="wednesday">Wednesday</option>
                      <option value="thursday">Thursday</option>
                      <option value="friday">Friday</option>
                      <option value="saturday">Saturday</option>
                      <option value="sunday">Sunday</option>
                    </select>
                  </div>
                )}
                
                <div>
                  <label className="block text-gray-700 text-sm font-bold mb-2">
                    Start Date
                  </label>
                  <input
                    type="date"
                    name="start_date"
                    value={newSchedule.start_date}
                    onChange={handleInputChange}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    required
                  />
                </div>
                
                <div>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      name="notifications"
                      checked={newSchedule.notifications}
                      onChange={handleInputChange}
                      className="mr-2"
                    />
                    <span className="text-gray-700">Enable email notifications</span>
                  </label>
                </div>
              </div>
              
              <div className="flex justify-end mt-6 space-x-2">
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
                >
                  Cancel
                </button>
                <button
                  onClick={createSchedule}
                  disabled={!newSchedule.template_id || !newSchedule.location || !newSchedule.start_date}
                  className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded disabled:opacity-50"
                >
                  Create Schedule
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </ProtectedRoute>
  );
}
