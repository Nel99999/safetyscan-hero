export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          created_at: string
          email: string
          full_name: string | null
          company: string | null
          avatar_url: string | null
          role: string
          updated_at: string | null
        }
        Insert: {
          id: string
          created_at?: string
          email: string
          full_name?: string | null
          company?: string | null
          avatar_url?: string | null
          role?: string
          updated_at?: string | null
        }
        Update: {
          id?: string
          created_at?: string
          email?: string
          full_name?: string | null
          company?: string | null
          avatar_url?: string | null
          role?: string
          updated_at?: string | null
        }
      }
      templates: {
        Row: {
          id: number
          created_at: string
          title: string
          description: string
          user_id: string | null
          version: number
          category: string | null
          tags: string[] | null
        }
        Insert: {
          id?: number
          created_at?: string
          title: string
          description: string
          user_id?: string | null
          version?: number
          category?: string | null
          tags?: string[] | null
        }
        Update: {
          id?: number
          created_at?: string
          title?: string
          description?: string
          user_id?: string | null
          version?: number
          category?: string | null
          tags?: string[] | null
        }
      }
      inspections: {
        Row: {
          id: number
          created_at: string
          template_id: number
          status: string
          metadata: Json
          findings: Json
          user_id: string | null
          completed_at: string | null
          signature_url: string | null
        }
        Insert: {
          id?: number
          created_at?: string
          template_id: number
          status: string
          metadata: Json
          findings?: Json
          user_id?: string | null
          completed_at?: string | null
          signature_url?: string | null
        }
        Update: {
          id?: number
          created_at?: string
          template_id?: number
          status?: string
          metadata?: Json
          findings?: Json
          user_id?: string | null
          completed_at?: string | null
          signature_url?: string | null
        }
      }
    }
  }
}
